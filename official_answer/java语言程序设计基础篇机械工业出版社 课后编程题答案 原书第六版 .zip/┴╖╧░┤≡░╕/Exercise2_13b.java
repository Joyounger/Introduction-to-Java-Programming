import java.util.Scanner;
public class Exercise2_13b{
    public static void main(String[] args){
        System.out.print("������");
        Scanner input = new Scanner(System.in);
        double balance = input.nextDouble();
        System.out.print("���������ʣ�");
        double annualInterestRate = input.nextDouble();
        double interest = balance*(annualInterestRate/1200);
        String output = "����Ϊ: " + interest;
        System.out.println(output);
        }
    }