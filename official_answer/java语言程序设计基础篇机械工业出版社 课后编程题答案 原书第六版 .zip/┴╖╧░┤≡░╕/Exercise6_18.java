
public class Exercise6_18 {

	public static void main(String[] args) {
		double[] list = {6.0,4.4,1.9,2.9,3.4,2.9,3.5};
		bubbleSort(list);
		System.out.print("ð������Ľ��:");
		for(int i = 0;i < list.length;i++)
			System.out.print("  " + list[i]);
	}

	private static void bubbleSort(double[] list) {
		boolean changed = true;
		double temp;
		do{
			changed = false;
			for(int j = 0; j < list.length- 1;j++)
				if(list[j] > list[j + 1]){
					temp = list[j];
					list[j] = list[j+1];
					list[j+1] = temp;
					changed = true;
				}
		}while(changed);
	}

}
