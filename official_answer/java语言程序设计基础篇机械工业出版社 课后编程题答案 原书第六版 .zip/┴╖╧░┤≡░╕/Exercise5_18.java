public class Exercise5_18{
	public static void main(String[] args){
		double value = 0;
		System.out.println("  ����\tƽ����\n");
		for(int i =0; i<=20;i++){
			value = Math.sqrt(i);
			value = (int)(value*10000)/10000.0;
			System.out.println("  " + i + "\t" + value);
			}
		}
	}