import java.util.Scanner;
public class Exercise4_29 {
	public static void main(String[] args){
		boolean isLeapYear = false;
		String monthName = "";
		int year,month,startDay = 0,i =0;
		int numberOfDay=0;
		Scanner input = new Scanner(System.in);
		System.out.print("����Ҫ��ʾ��������ݣ�");
		year = input.nextInt();
		System.out.print("����ĵ�һ�������ڼ�����");
		startDay = input.nextInt();
		System.out.println("\n��ӡ " + year + " ������:\n");
		for(month = 1;month<=12;month++){
			switch(month){
			case 1: monthName = "January";break;
			case 2: monthName = "February";break;
			case 3: monthName = "March";break;
			case 4: monthName = "April";break;
			case 5: monthName = "May";break;
			case 6: monthName = "June";break;
			case 7: monthName = "July";break;
			case 8: monthName = "Auguse";break;
			case 9: monthName = "September";break;
			case 10: monthName = "October";break;
			case 11: monthName = "November";break;
			case 12: monthName = "December";break;
			}
		System.out.println("           " + monthName + "  " + year);
		System.out.println("===================================");
		System.out.println("  Sun  Mon  Tue  Wed  Thu  Fri  Sat");
		for(i=0;i<startDay;i++)
			System.out.print("     ");
		isLeapYear = ((year%4==0&&year%100!=0)&&(year%400==0));
		if(isLeapYear&&month == 2)
			numberOfDay = 29;
		else if (month==4||month==6||month==9||month==11)
			numberOfDay = 30;
		else if(month == 2)
			numberOfDay = 28;
		else numberOfDay = 31;

		for(i =1;i<= numberOfDay;i++){
			if(i<10)
				System.out.print("    " + i);
			else
				System.out.print("   " + i);
			if((i + startDay )%7 == 0)
				System.out.println();
			}
			startDay = (i + startDay - 1)%7;
		System.out.println();

		}
	}
}
