
public class Exercise6_9 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] num = {1,2,4,5,10,100,2,-22};
		System.out.println("����num����СԪ��Ϊ��" + min(num));
	}

	private static int min(int[] num) {
		int min = num[0];
		for(int i = 1;i < num.length;i++)
			if(num[i]< min)
				min = num[i];
		return min;
	}

}
