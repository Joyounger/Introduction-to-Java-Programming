
public class Exercise4_14 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 0;
		System.out.println("输出'!'到'~'的ACSII码值：");
		for(int i = (int)'!';i < (int)'~';i++){
			n++;
			if(n % 10 == 0)
				System.out.println((char)i);
			else
				System.out.print((char)i + "  ");
		}
	}

}
