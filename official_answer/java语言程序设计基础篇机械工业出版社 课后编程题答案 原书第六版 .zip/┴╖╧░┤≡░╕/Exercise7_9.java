
public class Exercise7_9 {

	public static void main(String[] args) {
		MyInteger myInt = new MyInteger(5);
		System.out.println("整数的数值：" + myInt.getValue());
		System.out.println("是否为偶数：" + myInt.isEven());
		System.out.println(myInt.parseInt("10"));
	}

}
class MyInteger{
	private int value;
	public MyInteger(int value){
		this.value = value;
	}
	public int getValue(){
		return value;
	}
	public boolean isEven(){
		return isEven(value);
	}
	public boolean isOdd(){
		return isOdd(value);
	}
	public boolean isPrime(){
		return isPrime(value);
	}
	public static boolean isEven(int value){
		return value % 2 == 0;
	}
	public static boolean isOdd(int value){
		return value % 2 != 0;
	}
	public static boolean isPrime(int value){
		boolean isPrime = true;
		for(int i = 2; i < value / 2;i++)
			if(value % i == 0){
				isPrime = false;
				break;
			}
		return isPrime;
	}
	public boolean equals(int value){
		return this.value == value;
	}
	public boolean equals(MyInteger myInteger){
		return value == myInteger.getValue();
	}
	public static int parseInt(String numString){
		int num = 0;
		for(int i = 0;i < numString.length();i++)
			if(Character.isDigit(numString.charAt(i)))
				num = num * 10 + (int)(numString.charAt(i) - '0');
			else
				System.out.println("输入非法字符");
		return num;
	}
}