import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise14_8 extends JFrame {
	
	public Exercise14_8(){
		JPanel jp = new ShowMessageWhenMousePressed();
		add(jp);
		jp.setFocusable(true);
	}
	public static void main(String[] args) {
		Exercise14_8 frame = new Exercise14_8();
		frame.setTitle("Exercise14_8");
		frame.setSize(200,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	static class ShowMessageWhenMousePressed extends JPanel{
		private int x = 20;
		private int y = 20;
		private char keyChar = 'A';
		public ShowMessageWhenMousePressed(){
			addKeyListener(new KeyAdapter(){
				public void keyPressed(KeyEvent e){
					keyChar = e.getKeyChar();
					repaint();
				}
			});
			addMouseListener(new MouseAdapter(){
				public void mousePressed(MouseEvent e){
					x = e.getX();
					y = e.getY();
					repaint();
				}
			});
		}
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			g.setFont(new Font("TimesRoman",Font.BOLD,24));
			g.drawString(String.valueOf(keyChar), x, y);
		} 
	}
}
