import javax.swing.JOptionPane;
public class Exercise3_11{
	public static void main(String[] args){
		int day = 0;
		int year = Integer.parseInt(JOptionPane.showInputDialog("������ݣ�"));
		int month = Integer.parseInt(JOptionPane.showInputDialog("�����·ݣ�"));
		boolean isLeapYear = ((year % 4 == 0 && year % 100 != 0)||(year% 400 == 0));
		if(isLeapYear && month == 2)
			day = 29;
		else if(month==4||month==6||month==9||month==11)
			day = 30;
		else if(month==2)
			day = 28;
		else day = 31;
		String output = year + " �� " + month + " ���� " + day + " ��";
		JOptionPane.showMessageDialog(null,output);

		}
	}