import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;


public class Exercise14_10 extends JFrame {
	public Exercise14_10(){
		add(new FlashPanel("java is cool"));
	}
	public static void main(String[] args) {
		Exercise14_10 frame = new Exercise14_10();
		frame.setTitle("Exercise14_8");
		frame.setSize(300,300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

	}
	 class FlashPanel extends JPanel{	
		private boolean flag = false;
		private String message = "";
		public FlashPanel(String message){
			this.message = message;
			Timer time = new Timer(1000,new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					repaint();
					flag = !flag;
				}
				
			});
			time.start();
		}
		protected void paintComponent(Graphics g){
			super.paintComponents(g);
			if(flag)
				g.setColor(Color.black);
			else
				g.setColor(getBackground());
			g.setFont(new Font("TimesRoman",Font.BOLD,30));
			
			g.drawString(message, getWidth()/2-70, getHeight()/2-8);
		}
		
	}	
}
