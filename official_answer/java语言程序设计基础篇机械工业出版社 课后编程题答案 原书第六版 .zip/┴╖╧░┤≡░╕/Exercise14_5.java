import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise14_5 extends JFrame {
	
	public Exercise14_5(){
		add(new ChangeBackgroundPanel());
	}
	public static void main(String[] args) {
		Exercise14_5 frame = new Exercise14_5();
		frame.setTitle("Exercise14_5");
		frame.setSize(200,150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	static class ChangeBackgroundPanel extends JPanel{
		private Color color = Color.white;
		public ChangeBackgroundPanel(){
			addMouseListener(new MouseAdapter(){

				@Override
				public void mousePressed(MouseEvent arg0) {
					// TODO Auto-generated method stub
					color = Color.black;
					repaint();
				}

				@Override
				public void mouseReleased(MouseEvent arg0) {
					// TODO Auto-generated method stub
					color = Color.white;
					repaint();
				}
			});
		}
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			g.setColor(color);
			g.fillRect(0, 0, getWidth(), getHeight());
		}
	}
}
