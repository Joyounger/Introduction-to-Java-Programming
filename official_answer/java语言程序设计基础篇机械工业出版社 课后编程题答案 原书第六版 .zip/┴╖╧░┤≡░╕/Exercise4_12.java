
public class Exercise4_12 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 100;
		while(n*n < 12000){
			n++;
		}
		System.out.println("n的平方大于12000的最小整数是：" + n);
	}

}
