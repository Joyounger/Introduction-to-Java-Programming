import javax.swing.JOptionPane;


public class Exercise8_8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String binaryString = JOptionPane.showInputDialog("����һ��2������ת����16������");
		JOptionPane.showMessageDialog(null,binaryString + "ת����16����Ϊ��" + parseBinary(binaryString));
	}

	private static String parseBinary(String binaryString) {
		// TODO Auto-generated method stub
		int num;
		String output = "";
		for(int i = 0;i < binaryString.length();i += 4){
			num = 0;
			String binary = binaryString.substring(i, i+4);
			for(int j = 1; j <= 4;j++){
				num += (int)(binary.charAt(j - 1) - '0') * 
					Math.pow(2, binary.length() - j);
			}
			if(num >= 10)
				output += (char)(num + 55);	
			else
				output += num + "";
		}
		return output;
	}

}
