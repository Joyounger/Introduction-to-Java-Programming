import javax.swing.JOptionPane;
public class Exercise3_13{
	public static void main(String[] args){
		int num1 = (int)(Math.random()*100);
		int num2 = (int)(Math.random()*100);
		String output = num1 + " + " + num2 + " = ";
		int sum = Integer.parseInt(JOptionPane.showInputDialog(output));
		boolean isRight = (num1 + num2 == sum);
		if(isRight)
			output += sum + " is  correct!";
		else
			output += sum + " is  wrong!";
		JOptionPane.showMessageDialog(null,output);
		}
	}