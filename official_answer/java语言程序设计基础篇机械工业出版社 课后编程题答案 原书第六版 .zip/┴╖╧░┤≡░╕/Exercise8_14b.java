public class Exercise8_14b{
	public static void main(String[] args){
		if(args.length != 1){
			System.out.println("Usage:java Exercise8_14b \"num1 num2 ...\"");
			System.exit(0);
			}
		String[] str = args[0].split("\\s");
		double sum = 0;
		for(int i = 0;i < str.length;i++)
			sum += Double.parseDouble(str[i]);
			System.out.println("�������ĺ�Ϊ��" + sum);
		}
	}