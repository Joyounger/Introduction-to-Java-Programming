
public class Exercise6_14 {

	public static void main(String[] args) {
		computeAverage(1,2,3,4,5);
		computeAverage(new double[] {1,3,5});
	}
	public static void computeAverage(double ...numbers){
		if(numbers.length == 0){
			System.out.println("û�д��ݲ���");
			return;
		}
		double sum = 0;
		for(int i = 0; i < numbers.length;i++)
			sum += numbers[i];
		System.out.println("��������ƽ����Ϊ��" + sum/numbers.length);
	}
}
