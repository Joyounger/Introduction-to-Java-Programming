import javax.swing.JOptionPane;
public class Exercise3_1{
    public static void main(String[] args){
        double edge1 = Double.parseDouble(JOptionPane.showInputDialog(null,"�����һ���߳���"));
        double edge2 = Double.parseDouble(JOptionPane.showInputDialog(null,"����ڶ����߳���"));
        double edge3 = Double.parseDouble(JOptionPane.showInputDialog(null,"����������߳���"));
        boolean isTriangle = isTriangle(edge1,edge2,edge3);
        String output = "Can deges " + edge1 + " , " + edge2 + " and " + edge3 + " from a triangle? "+
        isTriangle;
        JOptionPane.showMessageDialog(null,output);
        }
    private static boolean isTriangle(double edge1,double edge2,double edge3){
        double temp;
        if(edge1<edge2){
            temp = edge1;
            edge1 = edge2;
            edge2 = temp;
            }
        if(edge1<edge3){
            temp = edge1;
            edge1 = edge3;
            edge3 = temp;
            }
        if(edge2<edge3){
            temp = edge2;
            edge2 = edge3;
            edge3 = temp;
            }
        if(edge1<(edge2+edge3))
            return true;
        else
            return false;
        }
    }