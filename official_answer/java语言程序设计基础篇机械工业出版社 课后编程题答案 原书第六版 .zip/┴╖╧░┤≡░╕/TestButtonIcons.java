import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


public class TestButtonIcons extends JFrame{
	public static void main(String[] args){
		TestButtonIcons frame = new TestButtonIcons();
		frame.setTitle("TestButtonIcons");
		frame.setSize(200,100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	public TestButtonIcons(){
		ImageIcon icon1 = new ImageIcon("src/images/1.gif");
		ImageIcon icon2 = new ImageIcon("src/images/2.gif");
		ImageIcon icon3 = new ImageIcon("src/images/3.gif");
		JButton jbt = new JButton("Click it",icon1);
		jbt.setPressedIcon(icon2);
		jbt.setRolloverIcon(icon3);
		add(jbt);
	}
}
