import javax.swing.JOptionPane;
public class Exercise4_28{
	public static void main(String[] args){
		boolean isLeapYear = false;
		String weekName = "";
		String monthName="";
		int month;
		int year = Integer.parseInt(JOptionPane.showInputDialog("������ݣ�"));
		int startDay = Integer.parseInt(JOptionPane.showInputDialog("��������һ���������?"));
		System.out.println("������Ϊ��");
		isLeapYear = ((year%4==0 && year % 100 != 0)||(year % 400 == 0));
		for(int monthOfNumber = 1;monthOfNumber<=12;monthOfNumber++){
					switch(monthOfNumber){
					case 1: monthName = "January";break;
					case 2: monthName = "February";break;
					case 3: monthName = "March";break;
					case 4: monthName = "April";break;
					case 5: monthName = "May";break;
					case 6: monthName = "June";break;
					case 7: monthName = "July";break;
					case 8: monthName = "Auguse";break;
					case 9: monthName = "September";break;
					case 10: monthName = "October";break;
					case 11: monthName = "November";break;
					case 12: monthName = "December";break;
		}
		month = monthOfNumber - 1;

		if(isLeapYear&&month == 2)
			startDay = (startDay + 29)%7;
		else if (month==4||month==6||month==9||month==11)
			startDay = (startDay + 30)%7;
		else if(month == 2)
			startDay = (startDay + 28)%7;
		else if(month == 0)
			startDay %= 7;
		else startDay = (startDay + 31)%7;

		switch(startDay){
			case 0: weekName = "Sunday";break;
			case 1: weekName = "Monday";break;
			case 2: weekName = "Tuesday";break;
			case 3: weekName = "Wednesday";break;
			case 4: weekName = "Thursday ";break;
			case 5: weekName = "Friday";break;
			case 6: weekName = "Saturday";break;
			}

		System.out.println(monthName + "   1 ,  " + year + "  is  " + weekName);
		}
	}
	}