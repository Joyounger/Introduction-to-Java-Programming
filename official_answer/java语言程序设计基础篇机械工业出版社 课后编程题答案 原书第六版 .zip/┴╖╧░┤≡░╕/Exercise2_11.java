import java.util.Scanner;
public class Exercise2_11{
    public static void main(String[] args){
        System.out.println("����Ǯ��������$ 11.56");
        Scanner input = new Scanner(System.in);
        double amount = input.nextDouble();
        int remainingAmount = (int)(amount*100);
        int numberOfOneDollars = remainingAmount/100;
        remainingAmount = remainingAmount%100;
        int numberOfQuarters = remainingAmount/25;
        remainingAmount = remainingAmount%25;
        int numberOfDimes = remainingAmount/10;
        remainingAmount %= 10;
        int numberOfNickels = remainingAmount/5;
        remainingAmount %= 5;
        int numberOfPennies = remainingAmount;
        String output = "Your amount $" + amount +" consists of\n" +
            numberOfOneDollars + " dollars\n" +
            numberOfQuarters + " quarters\n" +
            numberOfDimes + " dimes\n" +
            numberOfNickels + " nickels\n"+
            numberOfPennies + " pennies";
        System.out.println(output);
        }
    }