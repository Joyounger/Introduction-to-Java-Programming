
public class Exercise4_5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\t千克\t磅\t磅\t千克");
		for(int i = 20,n = 1;n < 200;n += 2,i += 5){
			System.out.print("\t" + n + "\t" + (int)(2.2*n*100)/100.0);
			System.out.println("\t" + i + "\t" + (int)(i/2.2*100)/100.0);
		}
	}

}
