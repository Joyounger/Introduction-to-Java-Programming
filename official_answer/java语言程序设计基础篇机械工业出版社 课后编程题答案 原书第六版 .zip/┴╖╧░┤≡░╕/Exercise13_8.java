import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Polygon;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise13_8 extends JFrame {

	public Exercise13_8(){
		add(new DrawPolygon());
	}
	public static void main(String[] args) {
		Exercise13_8 frame = new Exercise13_8();
		frame.setTitle("Exercise13_8");
		frame.setSize(550,80);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	static class DrawPolygon extends JPanel{
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			g.setColor(Color.red);
			Polygon polygon = new Polygon();
			int xCenter = getWidth()/2;
			int yCenter = getHeight()/2;
			int radius = (int)(Math.min(getWidth(), getHeight())*0.4);
			
			int cos = (int)(Math.cos(Math.PI/8));
			polygon.addPoint(xCenter-radius, yCenter);
			polygon.addPoint(xCenter-radius*cos, yCenter-radius*cos);
			polygon.addPoint(xCenter, yCenter-radius);
			polygon.addPoint(xCenter+radius*cos, yCenter-radius*cos);
			polygon.addPoint(xCenter+radius, yCenter);
			polygon.addPoint(xCenter+radius*cos, yCenter+radius*cos);
			polygon.addPoint(xCenter, yCenter+radius);
			polygon.addPoint(xCenter-radius*cos, yCenter+radius*cos);
			g.drawPolygon(polygon);
		}
		public Dimension getPerferredSized(){
			return new Dimension(200,200);
		}
	}
}
