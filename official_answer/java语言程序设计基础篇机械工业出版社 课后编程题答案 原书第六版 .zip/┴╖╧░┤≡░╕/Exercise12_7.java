import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Exercise12_7 extends JFrame {
	
	private ImageIcon cross = new ImageIcon("image/cross.jpg");
	private ImageIcon notCross= new ImageIcon("image/not.jpg");
	int num = 0;
	public Exercise12_7(){
		setLayout(new GridLayout(3,3,0,0));
		
		for(int i = 0; i < 9;i++){
			num = (int)(Math.random()*3);
			if(num == 0)
				add(new JLabel("O"));
			else if(num == 1)
				add(new JLabel("X"));
			else
				add(new JLabel("  "));
		}
	}
	public static void main(String[] args) {
		Exercise12_7 frame = new Exercise12_7();
		frame.setTitle("exercise12_7");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(270,270);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
