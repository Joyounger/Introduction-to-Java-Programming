import javax.swing.JOptionPane;
public class Exercise2_3{
    public static void main(String[] args){
        String foot = JOptionPane.showInputDialog(null,"����Ӣ������");
        double m = 0.305*Double.parseDouble(foot);
        String output = foot + " Ӣ���� " + m +" ��";
        JOptionPane.showMessageDialog(null,output);
        }
    }