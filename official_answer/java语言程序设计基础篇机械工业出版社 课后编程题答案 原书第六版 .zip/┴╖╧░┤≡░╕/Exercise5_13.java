public class Exercise5_13{
	public static void main(String[] args){
		System.out.println("i\tm(i)");
		for(int i = 2;i<=20; i++){
			System.out.println( i + "\t" +m(i-1));
			}
		}
	public static double m(int i){
		double sum = 0;
		for(int k = i;k>=1 ;k--)
			sum = sum + (double)k/(k+1);
		return sum;
		}
	}