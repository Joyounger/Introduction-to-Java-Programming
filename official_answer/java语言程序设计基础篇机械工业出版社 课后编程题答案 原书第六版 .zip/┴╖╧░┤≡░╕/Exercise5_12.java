import java.util.Scanner;
public class Exercise5_12{
	public static void main(String[] args){
		final int NUMBER_PER_LINE = 10;
		Scanner input = new Scanner(System.in);
		System.out.print("���뿪ʼ�ַ���");
		char startChar = input.next().toCharArray()[0];
		System.out.print("�����������");
		char endChar = input.next().toCharArray()[0];
		System.out.print("��ӡ "+ startChar + " �� " +
		 	endChar + " ֮����ַ�.\n ");
		printChars(startChar,endChar,NUMBER_PER_LINE);
		System.out.println();
		}
	public static void printChars(char ch1,char ch2,int numberPerLine){
		int start,end,count=0;
		if((int)ch1 > (int)ch2){
			start = (int)ch2;
			end = (int)ch1;
			}
		else{
			start = (int)ch1;
			end = (int)ch2;
			}
		while(start <= end){
			count ++;
			if(count % numberPerLine == 0)
				System.out.println((char)start);
			else
				System.out.print((char)start + "  ");
			start ++;
			}
		}
	}