import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise14_4b extends JFrame {

	public Exercise14_4b(){
		add(new ShowMouse());
	}
	public static void main(String[] args) {
		Exercise14_4b frame = new Exercise14_4b();
		frame.setTitle("Exercise14_4b");
		frame.setSize(250,250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	static class ShowMouse extends JPanel{
		private Color color = Color.black;
		private String message = "";
		private int x = 0;
		private int y = 0;
		public ShowMouse() {
			addMouseListener(new MouseAdapter(){

				public void mousePressed(MouseEvent e) {
					x = e.getX();
					y = e.getY();
					color = Color.black;
					message = "(" + x + "," + y +")";
					repaint();
				}

				public void mouseReleased(MouseEvent e) {
					color = getBackground();
					repaint();
				}
				
			});
		}
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			g.setColor(color);
			g.drawString(message,x,y);
		}
	}
}
