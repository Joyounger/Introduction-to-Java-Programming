import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise14_6 extends JFrame {

	public Exercise14_6(){
		add(new AlternativePanel());
	}
	public static void main(String[] args) {
		Exercise14_6 frame = new Exercise14_6();
		frame.setTitle("Exercise14_6");
		frame.setSize(300,300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	static class AlternativePanel extends JPanel{
		private String message = "";
		private boolean flag = true;
		private int x = 0;
		private int y = 0;
		public AlternativePanel(){
			addMouseListener(new MouseAdapter(){
				public void mousePressed(MouseEvent e){
					x = e.getX();
					y = e.getY();
					flag = !flag;
					repaint();
				}
			});
		}
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			if(flag)
				message = "Java is fun";
			else
				message = "Java is cool";
			g.setFont(new Font("TimesRoman",Font.BOLD,24));
			g.drawString(message,x, y);
		}
	}
}
