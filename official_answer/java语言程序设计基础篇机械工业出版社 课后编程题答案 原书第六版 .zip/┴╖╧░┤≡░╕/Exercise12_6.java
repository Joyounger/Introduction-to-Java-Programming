import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


public class Exercise12_6 extends JFrame{
	
	private ImageIcon usIcon = new ImageIcon("image/us.gif");
	private ImageIcon myIcon = new ImageIcon("image/us.gif");
	private ImageIcon frIcon = new ImageIcon("image/us.gif");
	private ImageIcon ukIcon = new ImageIcon("image/us.gif");
	
	public Exercise12_6(){
		setLayout(new GridLayout(2,2,0,0));
		Border lineBorder = new LineBorder(Color.BLACK,1);
		JLabel usLabel = new JLabel(usIcon); 
		usLabel.setBorder(lineBorder);
		JLabel myLabel = new JLabel(myIcon); 
		myLabel.setBorder(lineBorder);
		JLabel frLabel = new JLabel(frIcon); 
		frLabel.setBorder(lineBorder);
		JLabel ukLabel = new JLabel(ukIcon); 
		ukLabel.setBorder(lineBorder);
		
		add(usLabel);
		add(myLabel);
		add(frLabel);
		add(ukLabel);
	}
	public static void main(String[] args) {
		Exercise12_6 frame = new Exercise12_6();
		frame.setTitle("exercise12_6");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300,150);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
