import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;


public class Exercise8_22 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int[] num = new int[100];
			int j = 0;
			File file = new File("src/Exercise8_22.txt");
			Scanner input = new Scanner(file);
			PrintWriter output = new PrintWriter(file);
			for(int  i = 0;i < 100;i++)
				if((i+1) % 10 == 0)
					output.println((int)(Math.random()*1000));
				else 
					output.print((int)(Math.random()*1000) + " ");
			output.close();		
			while(input.hasNext()){
				num[j++] = input.nextInt();
			}
			Arrays.sort(num);
			for(int i = 0; i < num.length;i++)
				if((i + 1) % 10 == 0)
					System.out.println(num[i]);
				else
					System.out.print(num[i] + " ");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
