import javax.swing.JOptionPane;
public class Exercise5_4{
	public static void main(String[] args){
		int num = Integer.parseInt(JOptionPane.showInputDialog(null,"����һ��������"));
		int reverseNumber = reverse(num);
		JOptionPane.showMessageDialog(null,"��������Ϊ��"+reverseNumber);
		}
	public static int reverse(int number){
		int sum = 0;
		while(number>0){
			sum *=10;
			sum += number%10;
			number /= 10;
			}
		return sum;
		}
	}