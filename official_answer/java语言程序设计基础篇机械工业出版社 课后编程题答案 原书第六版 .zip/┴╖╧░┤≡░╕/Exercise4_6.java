
public class Exercise4_6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\t英里\t千米\t千米\t英里");
		for(int i = 1,n = 20; i <= 10; i ++,n += 5){
			System.out.print("\t" + i + "\t" + 1.609*i);
			System.out.println("\t" + n + "\t" + (int)(n/1.609*1000)/1000.0);
			
		}
	}

}
