package chapter10_6;

public class Exercise10_6 {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle(4,5);
		Rectangle r2 = new Rectangle(2,10);
		System.out.println("r1's area and r2's area is equal?" + r1.equals(r2));
	}

}
