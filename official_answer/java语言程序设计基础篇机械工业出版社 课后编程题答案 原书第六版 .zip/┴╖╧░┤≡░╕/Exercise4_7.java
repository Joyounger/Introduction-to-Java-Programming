
public class Exercise4_7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double cost = 10000;
		double rate = 0.05;
		double sum = 0;
		for(int i = 0;i < 14;i++){
			cost += cost*rate;
			if(i >= 10)
				sum += cost;
		}
		System.out.println("qqqqqqqq" + (int)(sum*100)/100.0);
	}

}
