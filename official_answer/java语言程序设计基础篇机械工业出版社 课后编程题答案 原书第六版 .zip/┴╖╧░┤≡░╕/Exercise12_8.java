import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


public class Exercise12_8 extends JFrame {
	public Exercise12_8(){
		setLayout(new GridLayout(2,3,0,0));
		Font font = new Font("TimesRoman",20, 0);
		String[] colorStr = {"black","blue","cyan","green","magenta","orange"};
		Color[] color = {Color.black,Color.blue,Color.cyan,Color.green,Color.magenta,Color.orange}; 
		Border lineBorder = new LineBorder(Color.YELLOW,1);
		for(int i = 0;i < 6;i++){
			JLabel label = new JLabel(colorStr[i]);
			
			label.setBorder(lineBorder);
			label.setForeground(color[i]);
			
			add(label);
		}
	}
	public static void main(String[] args) {
		Exercise12_8 frame = new Exercise12_8();
		frame.setTitle("exercise12_8");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300,150);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
