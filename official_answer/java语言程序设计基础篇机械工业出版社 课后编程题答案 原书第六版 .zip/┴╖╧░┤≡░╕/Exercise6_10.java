
public class Exercise6_10 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] num = {1,2,4,5,10,100,2,-22};
		System.out.println("��������СԪ�ص��±�Ϊ��" + indexOfMin(num));
	}

	private static int indexOfMin(int[] num) {
		int indexOfMin = 0;
		int min = num[0];
		for(int i = 1;i < num.length;i++){
			if(min > num[i]){
				min = num[i];
				indexOfMin = i;
			}
		}
		return indexOfMin;
	}

}
