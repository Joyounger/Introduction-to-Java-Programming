import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise12_1 extends JFrame{
	
	public Exercise12_1(){
		setLayout(new FlowLayout(FlowLayout.LEFT,15,15));
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		
		p1.setLayout(new FlowLayout());
		p2.setLayout(new FlowLayout());
		
		for(int i = 1;i <= 6;i++)
			if(i < 4)
				p1.add(new JButton("Button" + i));
			else
				p2.add(new JButton("Button" + i));
		add(p1);
		add(p2);
	}
	public static void main(String[] args) {
		Exercise12_1 frame = new Exercise12_1();
		frame.setSize(560,100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setTitle("Exercise12_1");
		frame.setVisible(true);
	}

}
