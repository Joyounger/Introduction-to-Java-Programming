import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class ButtonDemo extends JFrame {

	protected MessagePanel messagePanel = new MessagePanel("welcome to java");
	private JButton jbtLeft = new JButton("<=");
	private JButton jbtRight = new JButton("=>");
	public static void main(String[] args) {
		ButtonDemo frame = new ButtonDemo();
		frame.setTitle("ButtonDemo");
		frame.setSize(200,100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	public ButtonDemo(){
		messagePanel.setBackground(Color.white);
		JPanel jpButton = new JPanel();
		jpButton.setLayout(new FlowLayout());
		jpButton.add(jbtLeft);
		jpButton.add(jbtRight);
		jbtLeft.setMnemonic('L');
		jbtRight.setMnemonic('R');
		jbtLeft.setToolTipText("move message to left");
		jbtRight.setToolTipText("move message to right");
		setLayout(new BorderLayout());
		add(messagePanel,BorderLayout.CENTER);
		add(jpButton,BorderLayout.SOUTH);
		jbtLeft.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				messagePanel.moveLeft();
				repaint();
			}
		});
		jbtRight.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				messagePanel.moveRight();
				repaint();
			}
		});
	}
}
