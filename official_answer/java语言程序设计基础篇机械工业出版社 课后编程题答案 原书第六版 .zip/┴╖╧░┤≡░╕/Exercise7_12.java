import javax.swing.JOptionPane;
public class Exercise7_12 {
	public static void main(String[] args){
		StackOfIntegers stack = new StackOfIntegers();
		int num = Integer.parseInt(JOptionPane.showInputDialog("����һ�������������ӣ�"));
		int temp= num;
		int i = 2;
		while(i <= num){
			if(num % i == 0){
				stack.push(i);
				num /= i;
			}else
				i++;
		}
			System.out.print("��ʾ " + temp + " ����������:");
			while(! stack.empty())
				System.out.print(stack.pop() + " ");		
	}
}
 class StackOfIntegers{
	private int[] elements;
	private int size;
	public static final int DEFAULT_CAPACITY = 16;
	public StackOfIntegers(){
		this(DEFAULT_CAPACITY);
	}
	public StackOfIntegers(int capacity){
		elements = new int[capacity];
	}
	public int push(int value) {
		if(size >= elements.length){
			int[] temp = new int[elements.length*2];
			System.arraycopy(elements,0,temp,0,elements.length);
			elements = temp;
		}
		return elements[size++] = value;
	}

	public int pop() {
		return elements[--size];
	}

	public boolean empty() {
		return size == 0;
	}
	public int getSize(){
		return size;
	}
	public int peek(){
		return elements[size - 1];
	}
	
}