public class Exercise5_8{
	public static void main(String[] args){
		double celsius = 40;
		double fahrenheit = 120;
		System.out.println("\t����\t����\t����\t����");
		for(int i = 0;i<10;i++){
			System.out.print("\t" + celsius + "\t" + celsiusToFahrenheit(celsius));
			System.out.println("\t" + fahrenheit + "\t" + fahrenheitToCelsuis(fahrenheit));
			fahrenheit -= 10;
			celsius -= 1.0;
			}
		}
	public static double celsiusToFahrenheit(double celsius){
		return Math.round(((9.0/5)*celsius + 32)*100)/100.0;
		}
	public static double fahrenheitToCelsuis(double fahrenheit){
		return Math.round((fahrenheit-32)*5/9.0*100)/100.0;
		}
	}