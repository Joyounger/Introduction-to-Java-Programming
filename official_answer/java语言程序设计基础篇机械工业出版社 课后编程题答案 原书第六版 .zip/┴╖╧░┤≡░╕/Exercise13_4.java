import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise13_4 extends JFrame {
	public Exercise13_4(){
		add(new DrawMutiplicationTable());
	}
	public static void main(String[] args) {
		Exercise13_4 frame = new Exercise13_4();
		frame.setTitle("Exercise13_4");
		frame.setSize(400,400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	static class DrawMutiplicationTable extends JPanel{
		private int row = 0;
		private int column = 0;
		@Override
		protected void paintComponent(Graphics g) {
			// TODO Auto-generated method stub
			super.paintComponent(g);
			g.setFont(new Font("TimesRoman" ,Font.BOLD,24));
			g.drawString("Mutiplication Table", getWidth()/2-105, 50);
			g.setFont(new Font("TimesRoman" ,Font.PLAIN,14));
			for(int i = 0; i < 9 ;i++){
				g.drawString((i + 1) + "", getWidth()/2-105 + i*25, 75);
				g.drawString((i + 1) + "", getWidth()/2-135, 75 + (i + 1)*25);
			}
			g.drawRect(getWidth()/2-115, 85, 235, 225);
			for(row = 1;row < 10;row++)
				for(column = 1;column < 10;column++)
					g.drawString(row*column + "", getWidth()/2-130 + row*25, 75 + column*25);
		}

	}

}
