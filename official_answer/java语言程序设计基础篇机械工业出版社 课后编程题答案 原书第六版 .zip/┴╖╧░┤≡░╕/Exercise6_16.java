
public class Exercise6_16 {

	public static void main(String[] args) {
		int[] mylist = new int[100000];
		for(int i = 0; i < mylist.length; i++)
			mylist[i] = (int)(Math.random()*65535);
		int key = (int)(Math.random()*65535);
		long startTime = System.currentTimeMillis();
		int num = linearSearch(mylist, key);
		long endTime = System.currentTimeMillis();
		long executionTime = endTime - startTime;
		long start = System.currentTimeMillis();
		int search = binarySearch(mylist,key);
		long end = System.currentTimeMillis();
		long execution = end - start;
		System.out.println("���Բ��ҵĽ���������±�Ϊ��" + num +
				" ��������ʱ��" + executionTime);
		System.out.println("���ֲ��ҵĽ���������±�Ϊ��" + search + " ��������ʱ��" + execution);
	}

	private static int binarySearch(int[] mylist, int key) {
		for(int i =0; i < mylist.length; i++)
			if(key == mylist[i])
				return i;
		return -1;
	}

	private static int linearSearch(int[] mylist, int key) {
		int low = 0;
		int high = mylist.length - 1;
		while(high >= low){
			int mid = (high + low)/2;
			if(key < mylist[mid])
				high = mid -1;
			else if(key == mylist[mid])
				return mid;
			else low = mid + 1 ;
		}
		return low - 1;
	}

}
