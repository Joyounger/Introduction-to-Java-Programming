import java.util.Date;
public class Exercise7_3{
    public static void main(String[] args){
        Account account =   new Account(1122, 20000, 0.045);
        account.withDraw(2500);
        account.desposit(3000);
        String output = "���Ϊ��"+ account.getBalance() +
            "\n������Ϊ��" + account.getMonthlyInterestRate()*100+"%"+
            "\n�������ڣ�" + account.getDateCreated();
        System.out.println(output);
        }
    }
    class Account{
        private int id;
        private double balance;
        private double annualInterestRate;
        private Date dateCreated;

        public Account(int id, double balance, double annualInterestRate) {
            this.id = id;
            this.balance = balance;
            this.annualInterestRate = annualInterestRate;
            dateCreated = new Date();
          }

        public Account(){
            id = 0;
            balance = 0;
            annualInterestRate = 0;
            dateCreated = new Date();
            }

        public void setId(int id){
            this.id = id;
            }
        public void setBalance(double balance){
            this.balance = balance;
            }
        public void setAnnualInterestRate(double rate){
            this.balance = (balance>=0)? balance:0;
            }
        public int getId(){
            return id;
            }
        public double getAnnualInterestRate(){
            return annualInterestRate;
            }
        public String getDateCreated(){
            return dateCreated.toString();
            }
        public double getMonthlyInterestRate(){
            return annualInterestRate/12.0;
            }
        public void withDraw(double count){
            balance -= count;
            }
        public void desposit(double count){
            balance += count;
            }
        public double getBalance(){

            return balance;

            }
        }

