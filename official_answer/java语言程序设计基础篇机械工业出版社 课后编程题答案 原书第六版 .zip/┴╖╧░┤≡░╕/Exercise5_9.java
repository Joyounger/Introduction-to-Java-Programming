public class Exercise5_9{
	public static void main(String[] args){
		final int COLUMN = 10;
		double meter = 20;
		double foot = 1.0;
		System.out.println("\tӢ��\t��\t��\tӢ��");
		for(int i = 0;i<COLUMN;i++){
			System.out.print("\t" + foot + "\t" + footToMeter(foot));
			System.out.println("\t" + meter + "\t" + meterToFoot(meter));
			meter +=5;
			foot +=1.0;
			}
		}
	public static double footToMeter(double foot){
		return 0.305*foot;
		}
	public static double meterToFoot(double meter){
		return meter/0.305;
		}
	}