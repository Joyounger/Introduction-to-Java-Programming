import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise13_7 extends JFrame {

	/**
	 * @param args
	 */
	public Exercise13_7(){
		setLayout(new GridLayout(3,3,0,0));
		for(int i = 0;i < 9;i++){
			int type = (int)(Math.random()*3);
			add(new NewPanel(type));
		}
	}
	public static void main(String[] args) {
		Exercise13_7 frame = new Exercise13_7();
		frame.setTitle("Exercise13_7");
		frame.setSize(200,150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	static class NewPanel extends JPanel{
		private final int X = 0;
		private final int OVAL = 1;
		private int type;
		public NewPanel(int type){
			this.type = type;
		}
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			int width = getWidth();
			int height = getHeight();
			switch(type){
			case X: 
				g.setColor(Color.red);
				g.drawLine(10, 10, width-10, height-10);
				g.drawLine(10, height-10, width-10, 10);
				break;
			case OVAL:
				g.setColor(Color.blue);
				g.drawOval(10, 10, width-20, height-20);
				break;
			}
		}
		public Dimension getPerferredSize(){
			return new Dimension(100,75);
		}
	}
}
