
public class Exercise6_12 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] array = new int[10];
		for(int i = 0; i < array.length; i++)
			array[i] = i + 1;
		System.out.println("ԭʼ����Ϊ�� ");
		for(int i =0; i < array.length;i++)
			System.out.print("  " + array[i]);
		array = reverse(array);
		System.out.println("\n���õ�����Ϊ��");
		for(int i =0; i < array.length;i++)
			System.out.print("  " + array[i]);
	}

	private static int[] reverse(int[] array) {
		int temp = 0;
		int j = array.length - 1;
		for(int i = 0; i <= j;i++){
			temp = array[i];
			array[i] = array[j];
			array[j] = temp;
			j--;
		}
		return array;
	}

}
