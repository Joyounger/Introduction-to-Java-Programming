
public class Exercise4_23 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 50000;
		double sumLeftToRight = 0;
		double sumRihgtToLeft = 0;
		System.out.print("从左到右的计算结果为：");
		for(int i = 1; i <= n;i++){
			sumLeftToRight += 1.0/i;
		}
		System.out.println(sumLeftToRight);
		System.out.print("从右往左的计算结果为：");
		for(int i = n;i > 0;i--){
			sumRihgtToLeft += 1.0/i;
		}
		System.out.println(sumRihgtToLeft);
		System.out.println("结果相差：" +(sumRihgtToLeft - sumLeftToRight));
	}

}
