import javax.swing.JOptionPane;


public class Exercise8_10 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = Integer.parseInt(JOptionPane.showInputDialog("ʮ����ת���ɶ�����"));
		JOptionPane.showMessageDialog(null,num + "ת���ɶ���������" + conertDecimalToBinary(num));
	}

	private static String conertDecimalToBinary(int num) {
		// TODO Auto-generated method stub
		StringBuffer strBuf = new StringBuffer();
		while(num > 0){
			strBuf.append(num % 2);
			num /= 2;
		}
		return strBuf.reverse().toString();
	}

}
