import javax.swing.JOptionPane;
public class Exercise5_17{
	public static void main(String[] args){
		int number = Integer.parseInt(JOptionPane.showInputDialog("����n����n��n�ľ���"));
		System.out.println("��ӡ���Ϊ��\n");
		printMatrix(number);
		}
	public static void printMatrix(int n){
		for(int column = 0; column < n;column ++){
			for(int row = 0; row<n; row++)
				System.out.print(Math.round(Math.random()) + " ");
			System.out.println();
		}
		}
	}