import javax.swing.JOptionPane;


public class Exercise4_21 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double loan = Double.parseDouble(JOptionPane.showInputDialog("输入贷款总量："));
		double year = Double.parseDouble(JOptionPane.showInputDialog("输入贷款期限："));
		double month = year*12;
		System.out.println("贷款总额：" + loan);
		System.out.println("贷款年数：" + year);
		System.out.println("\t利率\t月支付额\t\t总偿还额");
		for(double rate = 0.05; rate < 0.081;rate += 0.00125){
			double payment = Math.pow((1 + rate),year)*loan;
			double monthlyPayment = payment / month;
			System.out.println("\t" + (int)(rate*100*1000)/1000.0 + " %\t" + 
					(int)(monthlyPayment*100)/100.0 + "\t\t" + 
					(int)(payment*100)/100.0);
		}
	}

}
