
public class Exercise6_7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] counts = new int[10];
		int num = 0;
		for(int i = 0;i < 100;i++){
			num = (int)(Math.random()*10);
			counts[num]++;
		}
		System.out.println("ͳ�ƽ��Ϊ��");
		System.out.print("�������     ");
		for(int i = 0;i < counts.length ; i++)
			System.out.print("   " + i);
		System.out.print("\n���ִ�����");
		for(int i = 0;i < counts.length ; i++)
			if(counts[i] < 10)
				System.out.print("   " + counts[i]);
			else 
				System.out.print("  " + counts[i]);
		
	}

}
