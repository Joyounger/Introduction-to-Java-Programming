import java.io.*;
import java.util.Scanner;
public class Exercise8_21{
	public static void main(String[] args){
		try{
			File sourceFile = new File("D:/Exercise/score.txt");
					if(!sourceFile.exists()){
						System.out.println("�ļ�������");
						System.exit(0);
						}

			Scanner input = new Scanner(sourceFile);
			int count = 0;
					double sum = 0;
					while(input.hasNext()){
						sum += input.nextDouble();
						count++;
						}
			System.out.println("�������ĺ�Ϊ��" + sum + "\nƽ����Ϊ��" + sum / count);
			}catch(IOException e){
				}
		}
	}