import java.util.Scanner;
public class Exercise5_14{
	public static void main(String[] args){
		System.out.print("����i��ֵ: ");
		Scanner input = new Scanner(System.in);
		int num = input.nextInt();
		System.out.println("�� i = " + num +" ʱ��m(i)= " + m(num));
		}
	public static double m(int i){
		double sum = 1;
		double item = 0;
		for(int k = i;k>=1;k--){
			item = 1.0 / (2*k+1);
			if(k % 2 == 0)
				sum += item;
			else
				sum -= item;

			}
		return 4*sum;
		}
	}