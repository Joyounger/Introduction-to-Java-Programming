import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.JFrame;


public class Exercise14_2 extends JFrame {

	/**
	 * @param args
	 */
	public Exercise14_2(){
		addComponentListener(new ComponentListener(){

			public void componentHidden(ComponentEvent e) {
				System.out.println("触发componentHidden事件");
			}

			public void componentMoved(ComponentEvent e) {
				System.out.println("触发componentMoved事件");
			}
			public void componentResized(ComponentEvent e) {
				System.out.println("触发componentResized事件");
			}

			public void componentShown(ComponentEvent e) {
				System.out.println("触发componentShown事件");
			}});
	}
	public static void main(String[] args) {
		Exercise14_2 frame = new Exercise14_2();
		frame.setTitle("Exercise14_2");
		frame.setSize(200,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
