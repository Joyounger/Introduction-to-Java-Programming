package chapter10;

public interface Colorable {
	public void howToColor(String color);
}
