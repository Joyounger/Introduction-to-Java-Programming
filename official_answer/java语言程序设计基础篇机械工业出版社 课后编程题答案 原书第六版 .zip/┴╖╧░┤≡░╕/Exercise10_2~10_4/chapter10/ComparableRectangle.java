package chapter10;

public class ComparableRectangle extends Rectangle implements Comparable{

	public ComparableRectangle(double width, double height) {
		super(width,height);
	}

	public int compareTo(Object o) {
		if(getArea() > ((ComparableRectangle)o).getArea())
			return 1;
		else if(getArea() < ((ComparableRectangle)o).getArea())
			return -1;
		else 
			return 0;
	}
	public static Comparable max(Comparable o1,Comparable o2){
		if(o1.compareTo(o2) > 0)
			return o1;
		else
			return o2;
	}
}
