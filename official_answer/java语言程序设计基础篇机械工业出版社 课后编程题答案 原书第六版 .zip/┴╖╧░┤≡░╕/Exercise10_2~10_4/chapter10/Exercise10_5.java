package chapter10;

public class Exercise10_5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c1 = new Circle(5);
		Circle c2 = new Circle(4);
		System.out.println(c1.getRadius());
		System.out.println(c2.getRadius());
		System.out.println("c1's radius equals c2's radius?" + c1.equals(c2));
		System.out.println("c1's area is " + ((c1.compareTo(c2) > 0)? "greater than " : (c1.compareTo(
				c2) < 0 ? "lower than " : "equals ")) + "c2's area");
		
	}

}
