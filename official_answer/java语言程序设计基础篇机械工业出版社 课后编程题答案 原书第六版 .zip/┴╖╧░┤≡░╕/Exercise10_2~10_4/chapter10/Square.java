package chapter10;

public class Square extends GeometricObject implements Colorable{
	private double edge;
	
	public Square() {
		super();
	}
	public Square(double edge) {
		super();
		this.edge = edge;
	}
	
	public double getEdge() {
		return edge;
	}
	public void setEdge(double edge) {
		this.edge = edge;
	}
	public double getArea() {
		return edge*edge;
	}
	public double getPerimeter() {
		return edge*4;
	}
	public void howToColor(String color) {
		setColor(color);
	}
}
