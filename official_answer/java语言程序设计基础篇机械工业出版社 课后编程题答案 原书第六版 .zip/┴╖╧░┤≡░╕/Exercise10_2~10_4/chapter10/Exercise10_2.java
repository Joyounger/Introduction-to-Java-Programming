package chapter10;

public class Exercise10_2 {

	public static void main(String[] args) {
		ComparableRectangle rect1 = new ComparableRectangle(4,2);
		ComparableRectangle rect2 = new ComparableRectangle(3,4);
		System.out.println(ComparableRectangle.max(rect1,rect2));
	}

}
