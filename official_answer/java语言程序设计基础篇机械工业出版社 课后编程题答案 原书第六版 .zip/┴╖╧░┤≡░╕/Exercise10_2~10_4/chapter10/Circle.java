package chapter10;

public class Circle extends GeometricObject implements Comparable {
	
	private double radius;
	

	public Circle() {
		super();
	}

	public Circle(double radius) {
		super();
		this.radius = radius;
	}
	
	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public double getArea() {
		return radius * radius * Math.PI;
	}

	public double getPerimeter() {
		return 2 * radius * Math.PI;
	}

	public int compareTo(Object o) {
		if(getArea() > ((Circle)o).getArea() )
			return 1;
		else if(getArea() < ((Circle)o).getArea())
			return -1;
		else 
			return 0;
	}
	public String toString(){
		return super.toString() + "\nrasius: " + radius + 
			"\narea: " + getArea() + "perimeter: " + getPerimeter();
	}
	public boolean equals(Object o){
		return radius == ((Circle)o).radius;
	}
	public int hasCode(){
		return (int)(radius * 1999711);
	}
}
