package chapter10;

import java.util.Date;

public class Exercise10_4 implements Cloneable, Comparable {
	private int id;
	private double area;
	private Date whenBuilt;
	
	public Exercise10_4() {
		super();
	}
	
	public Exercise10_4(int id, double area) {
		super();
		this.id = id;
		this.area = area;
		whenBuilt = new Date();
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}
	
	public Date getWhenBuilt() {
		return whenBuilt;
	}

	public int compareTo(Object o) {
		if(area > ((Exercise10_4)o).area)
			return 1;
		else if(area < ((Exercise10_4)o).area)
			return -1;
		else 
			return 0;
	}
	public Object clone(){
		Exercise10_4 h = new Exercise10_4();
		h.whenBuilt = whenBuilt;
		return h;
	}
	public static void main(String[] args){
		Exercise10_4 house = new Exercise10_4(1,200);
		Exercise10_4 house1 = (Exercise10_4)house.clone();
		System.out.println(house == house1);
		System.out.println(house.getWhenBuilt() == house1.getWhenBuilt());
	}
}
