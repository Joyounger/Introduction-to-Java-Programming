package chapter10;

public class Exercise10_3 {

	public static void main(String[] args) {
		GeometricObject[] array = new GeometricObject[5];
		String[] color = {"red", "blue" ,"cyan","green","lightred"};
		array[0] = new Square(5);
		array[1] = new Rectangle();
		array[2] = new Rectangle(2,3);
		array[3] = new Square(3);
		array[4] = new Square(4);
		for(int i =0;i < array.length;i++)
			if(array[i] instanceof Colorable)
				((Colorable)array[i]).howToColor(color[i]);
		for(int i =0;i < array.length;i++)
			System.out.println(array[i].getClass() + " color:" + array[i].getColor());
	}

}
