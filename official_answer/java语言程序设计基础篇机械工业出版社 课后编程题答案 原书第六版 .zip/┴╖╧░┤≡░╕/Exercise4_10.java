
public class Exercise4_10 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 0;
		System.out.println("输出100~1000之间能被5和6整除的数:");
		for(int i =100;i < 1000; i++){
			if(i % 5 == 0 && i % 6 == 0){
				n++;
				if(n % 10 == 0)
					System.out.println(i);
				else
					System.out.print(i + "  ");
			}
		}
	}

}
