
public class Exercise4_13 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 1;
		while(n*n*n < 12000){
			n++;
		}
		System.out.println("n的立方小于12000的最大整数是：" + (n - 1));
	}

}
