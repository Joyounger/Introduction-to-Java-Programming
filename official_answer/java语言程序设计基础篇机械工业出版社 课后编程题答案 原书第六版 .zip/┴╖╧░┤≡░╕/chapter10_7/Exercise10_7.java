package chapter10_7;

public class Exercise10_7 {

	public static void main(String[] args) {
		Octagon octagon = new Octagon(5);
		Octagon oct = null;
		try {
			 oct = (Octagon) octagon.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		System.out.println(oct == octagon );
		System.out.println(oct);
		System.out.println(octagon);
		System.out.println("octagon compare to oct?" + octagon.compareTo(oct));
	}

}
