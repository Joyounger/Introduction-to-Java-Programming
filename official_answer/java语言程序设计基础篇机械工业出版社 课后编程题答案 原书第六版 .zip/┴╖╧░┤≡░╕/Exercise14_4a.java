import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise14_4a extends JFrame {
	
	public Exercise14_4a(){
		add(new ShowMousePoint());
	}
	public static void main(String[] args) {
		Exercise14_4a frame = new Exercise14_4a();
		frame.setTitle("Exercise14_4a");
		frame.setSize(200,150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	static class ShowMousePoint extends JPanel{
		private String message = "";
		private int x = 0;
		private int y = 0;
		public ShowMousePoint(){
			addMouseListener(new MouseAdapter(){
				public void mousePressed(MouseEvent e){
					x = e.getX();
					y = e.getY();
					message = "(" + x + "," + y + ")";
					repaint();
				}
			});
		}
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			g.drawString(message, x, y);
		}
	}
}
