
public class Exercise7_4 {

	public static void main(String[] args) {
		Stock stock = new Stock("SUNW","sun mircosystem inc.");
		stock.setPreviousClosingPrice(100);
		stock.setCurrentPrice(90);
		System.out.println("��Ʊ���ţ�" + stock.getSymbol() +
				"\n��Ʊ���ƣ�" + stock.getName() + 
				"\n" + stock.changePercent());
	}

}
class Stock{
	private String name;
	private double previousClosingPrice = 0;
	private double currentPrice = 0;
	public Stock(String symbol,String name){
		this.symbol = symbol;
		this.name = name;
	}
	private String symbol;
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPreviousClosingPrice() {
		return previousClosingPrice;
	}
	public void setPreviousClosingPrice(double previousClosingPrice) {
		this.previousClosingPrice = previousClosingPrice;
	}
	public double getCurrentPrice() {
		return currentPrice;
	}
	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}
	public String changePercent(){
		String output = "";
		double add = (currentPrice - previousClosingPrice)/previousClosingPrice;
		add = (int)(add * 100)/1.0;
		if(add >= 0)
			output = "���ձ���������  " + add + " %";
		else
			output = "���ձ������½� " + (- add) + " %";
		return output;
	}
	
}