
public class Exercise6_13 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] list = new int[5];
		for(int i = 1; i<=list.length;i++){
			list[i - 1] = i;
		}
		list = doubleCapacity(list);
		System.out.println("��������е����ݣ�");
		for(int i = 0;i < list.length;i++)
			System.out.print("  " + list[i]);
	}

	private static int[] doubleCapacity(int[] list) {
		int[] newList = new int[list.length*2];
		System.arraycopy(list, 0, newList, 0, list.length);
		return newList;
	}

}
