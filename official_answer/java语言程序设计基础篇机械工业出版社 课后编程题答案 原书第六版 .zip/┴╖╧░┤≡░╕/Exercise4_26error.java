
public class Exercise4_26error {
//注意item的数值类型如果为long则程序会出现错误。e的结果是：Infinity。改为double类型程序就不会出错误了。
	public static void main(String[] args) {
		for(int i = 10000;i <= 100000; i += 10000){
			double sum = 1;
			long item = 1;
			for(int j = 1; j <= i;j++){
				item *= j;
				sum += 1.0 / item;
			}
			System.out.println("当 i = " + i + " 时，e 的值为：" + sum);
		}
	}

}
