import javax.swing.JOptionPane;
public class Exercise4_18 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String numString = "";
		int num = Integer.parseInt(JOptionPane.showInputDialog("输入打印第几个金字塔(1~4)"));
		switch(num){
			case 1: numString = "I";break;
			case 2: numString = "II";break;
			case 3: numString = "III";break;
			case 4: numString = "IV";break;
			default:{
				System.out.println("输入错误，程序终止");
				System.exit(0);
			}
		}
		System.out.println("Pattern " + numString);
		drawPattern(num);
	}

	private static void drawPattern(int i) {
		// TODO Auto-generated method stub
		if(i == 1){
			for(int j = 1; j <= 6;j++){
				for(int k = 1; k <= j;k++)
					System.out.print(k + " ");
				System.out.println();
			}
		}else if(i == 2){
			for(int j = 6;j > 0;j--){
				for(int k = j; k > 0;k--)
					System.out.print(k + " ");
				System.out.println();
			}
		}else if(i == 3){
			for(int j = 1; j <= 6 ;j++){
				for(int n=0;n<6-j;n++)
					System.out.print("  ");
				for(int k = j;k > 0;k--)
					System.out.print(k + " ");
				System.out.println();	
			}
		}else{
			for(int j = 6; j > 0;j--){
				for(int n = 1; n <= 6-j;n++)
					System.out.print("  ");
				for(int k = j; k > 0;k--)
					System.out.print(k + " ");
				System.out.println();
			}
				
		}
	}

}
