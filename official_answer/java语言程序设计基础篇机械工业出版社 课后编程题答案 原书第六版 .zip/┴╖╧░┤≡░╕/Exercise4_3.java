
public class Exercise4_3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\t千克\t磅");
		for(int i = 1;i < 200; i += 2){
			System.out.println("\t" + i + "\t" + (int)(i*2.2*10)/10.0);
		}
	}

}
