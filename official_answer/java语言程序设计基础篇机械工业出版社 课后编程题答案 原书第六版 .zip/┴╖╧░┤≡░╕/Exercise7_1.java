
public class Exercise7_1 {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle(4,40);
		r1.setColor("red");
		Rectangle r2 = new Rectangle(3.5,35.9);
		r2.setColor("red");
		System.out.println(r1.toString());
		System.out.println(r2.toString());
	}

}
class Rectangle{
	private double width = 1;
	private double height = 1;
	private String color = "white";
	public Rectangle(){
		this(1.0,1.0);
	}
	public Rectangle(double width,double height){
		this.width = width;
		this.height = height;
		color = "white";
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public double getArea(){
		return width*height;
	}
	public double getPerimeter(){
		return (width + height)*2;
	}
	public String toString(){
		String output = "";
		output = "���ε�����:\n\t�� " + width + "\n\t�ߣ�" + height +"\n\t��ɫ��" +
			color + "\n\t�����" + getArea() + "\n\t�ܳ���" + getPerimeter();
		return output;
	}
}
