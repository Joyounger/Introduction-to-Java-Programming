import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise14_3 extends JFrame {

	public Exercise14_3(){
		add(new ClickPanel());
	}
	public static void main(String[] args) {
		Exercise14_3 frame = new Exercise14_3();
		frame.setTitle("Exercise14_3");
		frame.setSize(200,150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
	}
	static class ClickPanel extends JPanel implements ActionListener{
		JButton jbtOK = new JButton("ok");
		JButton jbtCancel = new JButton("cancel");
		private String message = "";
		public ClickPanel(){
			setLayout(new FlowLayout(FlowLayout.CENTER,10,60));
			add(jbtOK);
			add(jbtCancel);
			jbtOK.addActionListener(this);
			jbtCancel.addActionListener(this);
			
		}
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == jbtOK)
				message = "OK";
			else if(e.getSource() == jbtCancel)
				message = "Cancel";
			repaint();
		}
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			g.drawString("The " + message + " button is clicked", getWidth()/2-70, 40);
		}
	}
}
