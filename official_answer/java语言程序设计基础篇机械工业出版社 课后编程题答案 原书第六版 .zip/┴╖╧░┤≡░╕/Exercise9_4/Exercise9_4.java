import java.util.ArrayList;


public class Exercise9_4 {
	
	public static void main(String[] args) {
		MyStack stack = new MyStack();
		String[] str = {"Hello" , "World"};
		for(int i = 0;i < str.length;i++)
			stack.push(str[i]);
		System.out.println(stack.size());
		System.out.println(stack);
		System.out.println(stack.pop());
	}

}
