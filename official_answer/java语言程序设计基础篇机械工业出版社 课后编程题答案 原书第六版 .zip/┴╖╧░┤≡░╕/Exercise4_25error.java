public class Exercise4_25error {
//可以与Exercise4_25的程序进行比较。观察变量的作用域。
	public static void main(String[] args) {
		int count = 0;
		double pi = 0;
		for(int i = 10000; i <= 100000; i += 10000){
			for(int j = 1; j <= (2*i + 1);j += 2){
				count++;
				if(count % 2 == 0)
					pi -= 1.0/j;
				else 
					pi += 1.0/j;
			}
			System.out.println("当 i = " + i + " 时π的值为：" + pi*4);
		}
		
	}

}
