import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


public class Exercise12_5 extends JFrame{
	public Exercise12_5(){
		JPanel jp = new JPanel(new GridLayout(4,1,0,0));
		JLabel label1 = new JLabel("Department of Computer Science");
		JLabel label2 = new JLabel("School of computing");
		JLabel label3 = new JLabel("Armstong Atlantic state University");
		JLabel label4 = new JLabel("Tel:(912) 921-6440");
		
		Border lineBorder = new LineBorder(Color.BLACK,1);
		
		label1.setBorder(lineBorder);
		label2.setBorder(lineBorder);
		label3.setBorder(lineBorder);
		label4.setBorder(lineBorder);
		
		jp.add(label1);
		jp.add(label2);
		jp.add(label3);
		jp.add(label4);
		
		add(jp);
	}
	public static void main(String[] args){
		Exercise12_5 frame = new Exercise12_5();
		frame.setTitle("exercise12_5");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300,150);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
