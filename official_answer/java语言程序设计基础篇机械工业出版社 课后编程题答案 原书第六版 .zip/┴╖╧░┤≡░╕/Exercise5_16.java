public class Exercise5_16{
	public static void main(String[] args){
		final int NUMBER_OF_PRIMES = 1000;
		final int NMBER_OF_PRIMES_PER_LINE = 10;
		int count = 1;
		int number = 2;
		System.out.println("The first prime number numbers are \n");
		while(count <= NUMBER_OF_PRIMES){
			if(isPrime(number)){
				if(number<10)
					System.out.print("   ");
				else if(number<100)
					System.out.print("  ");
				else if(number<1000)
					System.out.print(" ");

				if(count % NMBER_OF_PRIMES_PER_LINE == 0){
					System.out.println(number);
				}else{
					System.out.print(number + " ");
				}
				count ++;
				}
			number ++;
			}
		}
		public static boolean isPrime(int number){
			boolean isPrime = true;
			for(int divisor = 2;divisor <= number/2; divisor++){
				if(number % divisor == 0){
					isPrime = false;break;
					}
				}
			return isPrime;
			}
	}