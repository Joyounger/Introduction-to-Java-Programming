import javax.swing.JOptionPane;
public class Exercise3_2{
    public static void main(String[] args){
        int num = Integer.parseInt(JOptionPane.showInputDialog(null,"����һ������"));
        String output = "Is " + num + " an even number? " +isEven(num);
        JOptionPane.showMessageDialog(null,output);
        }
    private static boolean isEven(int num){
        if(num % 2 ==0)
            return true;
        else
            return false;
        }
    }