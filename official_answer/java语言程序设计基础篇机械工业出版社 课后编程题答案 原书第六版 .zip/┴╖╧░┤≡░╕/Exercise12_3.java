import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise12_3 extends JFrame{

	public Exercise12_3(){

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(2,3,0,10));
		for(int i = 1; i <= 6;i++)
			panel.add(new JButton("Button" + i));
		add(panel);
	}
	
	public static void main(String[] args) {
		Exercise12_3 frame = new Exercise12_3();
		frame.setSize(400,150);
		frame.setTitle("The Front view of a MicrowaveOven");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
