import javax.swing.JOptionPane;
public class Exercise5_21{
	public static void main(String[] args){
		int i;
		double average=0,variance=0,squares=0,sum=0;
		String output = "";
		for(i = 0;i < 10; i++){
			int num = (int)(Math.random()*1000);//ע��һ��Ҫ�����š�
			sum += num;
			squares += num * num;
			output += num + " , ";
			}
		average = average(sum,i);
		variance = variance(sum,squares,i);
		JOptionPane.showMessageDialog(null,output + "��\nƽ����Ϊ��" + average + "����Ϊ��" + variance);
		}
	public static double average(double sum , int num){
			return sum/num;
		}
	public static double variance(double sum,double squares,int num){
		double temp = Math.sqrt((squares*squares - sum*sum/num)/(num - 1));
		return temp;
		}
	}