public class Exercise5_20{
	public static void main(String[] args){
		double sinValue,cosValue;
		System.out.println(" �Ƕ�\t����ֵ\t����ֵ\n");
		for(int degree = 0;degree <= 360;degree += 10){
			sinValue = Math.sin(Math.toRadians(degree));
			sinValue = (int)(sinValue*10000)/10000.0;
			cosValue = Math.cos(Math.toRadians(degree));
			cosValue = (int)(cosValue*10000)/10000.0;
			System.out.println("  " + degree + "\t" +
				sinValue + "\t" + cosValue);
			}
		}
	}