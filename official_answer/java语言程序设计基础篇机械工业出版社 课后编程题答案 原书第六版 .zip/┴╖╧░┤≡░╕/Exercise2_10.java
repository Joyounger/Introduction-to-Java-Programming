import javax.swing.JOptionPane;
public class Exercise2_10{
    public static void main(String[] args){
        String amountString = JOptionPane.showInputDialog(null,"����һ������������$11.56����1156");
        int amount = Integer.parseInt(amountString);
        int numberOfOneDollars = amount/100;
        int remainingAmount = amount%100;
        int numberOfQuarters = remainingAmount/25;
        remainingAmount = remainingAmount%25;
        int numberOfDimes = remainingAmount/10;
        remainingAmount %= 10;
        int numberOfNickels = remainingAmount/5;
        remainingAmount %= 5;
        int numberOfPennies = remainingAmount;
        String output = "Your amount $" + amount/100.0 +" consists of\n" +
            numberOfOneDollars + " dollars\n" +
            numberOfQuarters + " quarters\n" +
            numberOfDimes + " dimes\n" +
            numberOfNickels + " nickels\n"+
            numberOfPennies + " pennies";
        JOptionPane.showMessageDialog(null,output);
        }
    }