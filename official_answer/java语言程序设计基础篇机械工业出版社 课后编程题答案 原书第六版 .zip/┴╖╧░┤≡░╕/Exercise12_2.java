import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise12_2 extends JFrame{

	public Exercise12_2(){
		setLayout(new BorderLayout(5,10));
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		
		p1.setLayout(new BorderLayout());
		p2.setLayout(new BorderLayout());
		
		p1.add(new JButton("Button 1"),BorderLayout.WEST);
		p1.add(new JButton("Button 2"),BorderLayout.CENTER);
		p1.add(new JButton("Button 3"),BorderLayout.EAST);
		
		p2.add(new JButton("Button 4"),BorderLayout.WEST);
		p2.add(new JButton("Button 5"),BorderLayout.CENTER);
		p2.add(new JButton("Button 6"),BorderLayout.EAST);
		
		add(p1,BorderLayout.CENTER);
		add(p2,BorderLayout.SOUTH);
	}
	
	public static void main(String[] args) {
		Exercise12_2 frame = new Exercise12_2();
		frame.setSize(300,100);
		frame.setTitle("Exercise12_2");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
