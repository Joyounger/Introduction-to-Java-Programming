import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise14_1 extends JFrame {

	/**
	 * @param args
	 */
	private int i = 0;
	public Exercise14_1(){
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		setLayout(new FlowLayout(FlowLayout.LEFT,10,5));
		JButton[] jbt = new JButton[6];
		add(p1);
		add(p2);
		for(i = 1;i <= jbt.length;i++){
			jbt[i-1] = new JButton("Button" + i);
			if(i < 4)
				p1.add(jbt[i-1]);
			else
				p2.add(jbt[i-1]);
			jbt[i - 1].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					System.out.println("The " + e.getActionCommand() + " is clicked");
				}
			});
		}
	}
	public static void main(String[] args) {
		Exercise14_1 frame = new Exercise14_1();
		frame.setTitle("Exercise14_1");
		frame.setSize(550,80);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
