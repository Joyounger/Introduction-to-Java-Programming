import chapter10.*;
import chapter10_7.*;

public class Exercise10_8 {

	public static void main(String[] args) {
		GeometricObject[] array = new GeometricObject[3];
		array[0] = new Circle(3);
		array[1] = new Octagon(4);
		array[2] = new Rectangle(3,4);
		for(int i = 0; i < array.length;i++)
			System.out.println(array[i].getClass() + " area is " + array[i].getArea());
		System.out.println("The sum area is " + sumArea(array));
	}

	public static double sumArea(GeometricObject[] array) {
		double sumArea = 0;
		for(int i = 0;i < array.length;i++)
			sumArea += array[i].getArea();
		return sumArea;
	}
}
