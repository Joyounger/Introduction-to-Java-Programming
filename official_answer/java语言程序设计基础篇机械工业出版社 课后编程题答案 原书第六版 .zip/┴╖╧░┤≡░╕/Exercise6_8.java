
public class Exercise6_8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1 = {1,2,3,4,5};
		double[] array2 = {1.2,1.3,2.3,2.5};
		System.out.println("����array1��ƽ����Ϊ�� " + average(array1));
		System.out.println("����array2��ƽ����Ϊ�� " + average(array2));
	}

	private static double average(double[] array) {
		// TODO Auto-generated method stub
		double sum = 0;
		for(int i = 0;i < array.length;i++)
			sum += array[i];
		
		return sum/array.length;
	}

	private static int average(int[] array) {
		// TODO Auto-generated method stub
		int sum = 0;
		for(int i = 0;i < array.length;i++)
			sum += array[i];
		
		return sum/array.length;
	}

}
