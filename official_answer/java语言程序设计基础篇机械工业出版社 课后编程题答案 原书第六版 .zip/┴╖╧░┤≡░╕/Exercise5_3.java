import javax.swing.JOptionPane;
public class Exercise5_3{
	public static void main(String[] args){
		int number = Integer.parseInt(JOptionPane.showInputDialog(null,"����һ��������"));
		reverse(number);
		}
	public static void reverse(int number){
		while(number>0){
			System.out.print(number%10);
			number /= 10;
			}
		}
	}