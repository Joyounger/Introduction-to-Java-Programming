import javax.swing.JOptionPane;


public class Exercise8_9 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int value = Integer.parseInt(JOptionPane.showInputDialog("ʮ����ת����ʮ������"));
		JOptionPane.showMessageDialog(null,value + "ת��Ϊʮ����������" + conertDecimalToHex(value));
	}

	private static String conertDecimalToHex(int value) {
		// TODO Auto-generated method stub
		StringBuilder output = new StringBuilder();
		int num = 0;
		while(value > 0){
			num = value % 16;
			if(num >= 10)
				output.append((char)(num + '7'));
			else
				output.append(num);
			value /= 16;
		}
		return output.reverse().toString();
	}

}
