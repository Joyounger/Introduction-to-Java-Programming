public class Exercise2_7{
    public static void main(String[] args){
        char uppercase = 'E';
        int offset = (int)'a' - (int)'A';
        char lowercase = (char)((int)uppercase + offset);
        System.out.println("�ַ� " + uppercase + " ת��ΪСд��ĸΪ��" + lowercase);
        }
    }