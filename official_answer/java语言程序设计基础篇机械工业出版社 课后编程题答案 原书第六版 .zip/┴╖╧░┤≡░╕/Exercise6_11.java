
public class Exercise6_11 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double[] array = new double[10];
		for(int i = 0; i < array.length; i++)
			array[i] = i + 1;
		System.out.println("��ı�׼��Ϊ��" + compute(array));

	}

	private static double compute(double[] array) {
		double average = 0;
		double sum = 0;
		for(int i =0; i<array.length;i++)
			sum += array[i];
		average = sum / array.length;
		for(int i = 0;i < array.length;i++)
			sum += Math.pow((array[i] - average), 2);
		return Math.sqrt(sum/(array.length - 1));
	}

}
