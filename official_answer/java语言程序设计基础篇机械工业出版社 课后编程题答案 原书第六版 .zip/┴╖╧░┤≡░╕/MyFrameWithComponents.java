import javax.swing.JButton;
import javax.swing.JFrame;


public class MyFrameWithComponents {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame frame = new JFrame("MyFrameWithComponents");
		JButton button = new JButton("ok");
		frame.add(button);
		frame.setSize(400,300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
	}

}
