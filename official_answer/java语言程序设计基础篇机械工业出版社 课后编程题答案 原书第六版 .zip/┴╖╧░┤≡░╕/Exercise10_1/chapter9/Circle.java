package chapter9;

public class Circle extends GeometricObject{
	
	private double radius;
	
	public Circle(){}
	public Circle(double radius){
		this.radius = radius;
	}
	
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public double getArea() {
		return radius*radius*Math.PI;
	}

	public double getPerimeter() {
		return 2*radius*Math.PI;
	}
	public String toString() {
		return super.toString() + "\nradius: " + radius + "\narea:" + getArea() + " perimeter: " + getPerimeter();
	}
	public Comparable max(Comparable o1, Comparable o2) {
		if(o1.compareTo(o2) > 0)
			return o1;
		else
			return o2;
	}
	public int compareTo(Object arg0) {
		return super.CompareTo(arg0);
	}

}
