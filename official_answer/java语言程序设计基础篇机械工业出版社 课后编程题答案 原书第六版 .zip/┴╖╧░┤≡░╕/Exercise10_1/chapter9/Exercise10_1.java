package chapter9;

public class Exercise10_1 {

	public static void main(String[] args) {
		GeometricObject circle = new Circle(5);
		circle.setFilled(true);
		circle.setColor("red");
		GeometricObject rect = new Rectangle(4,5);
		rect.setColor("blue");
		rect.setFilled(false);
		System.out.println(circle.toString());
		System.out.println(rect.toString());
		int flag = circle.compareTo(rect);
		System.out.println("circle's area " + (flag > 0 ? "great" : (flag == 0 ? "equal" : "lower")) + 
				" rectangle's area");
		System.out.println(circle.max(circle, rect));
	}

}
