package chapter9;

public class Rectangle extends GeometricObject{
	
	private double width;
	private double height;
	
	public Rectangle(){
	}
	public Rectangle(double width,double height){
		this.width = width;
		this.height = height;
	}
	
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	
	public double getArea() {
		return width*height;
	}

	public double getPerimeter() {
		return 2*(width + height);
	}
	public String toString() {
		return super.toString() + "\nwidth: " + width + " height: " + height + 
			"\narea: " + getArea() + " perimeter: " + getPerimeter();
	}
	public Comparable max(Comparable o1, Comparable o2) {
		if(o1.compareTo(o2) > 0)
			return o1;
		else
			return o2;
	}
	public int compareTo(Object arg0) {
		return super.CompareTo(arg0);
	}
	
}
