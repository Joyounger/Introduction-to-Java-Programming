import javax.swing.JOptionPane;


public class Exercise8_2 {

	public static void main(String[] args) {
		String s = JOptionPane.showInputDialog("����һ���ַ���");
		String output = "";
		if(isPalindrome(s))
			output = s + " �ǻ��Ĵ�";
		else 
			output = s + " ���ǻ��Ĵ�";
		JOptionPane.showMessageDialog(null,output);
	}

	private static boolean isPalindrome(String s) {
		int low = 0;
		int high = s.length() - 1;
		while(low < high){
			if(Character.toLowerCase(s.charAt(low)) != Character.toLowerCase(s.charAt(high)))
				return false;
			low++;
			high--;
		}
		return true;
	}

}
