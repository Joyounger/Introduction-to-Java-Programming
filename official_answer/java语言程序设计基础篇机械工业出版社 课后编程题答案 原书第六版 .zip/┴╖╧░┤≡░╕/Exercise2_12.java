
import javax.swing.JOptionPane;

public class Exercise2_12 {

    public static void main(String[] args) {
        String name;
        double hours, salary, ntax, ltax;
        
        name = JOptionPane.showInputDialog("姓名：");
        hours = Double.parseDouble(JOptionPane.showInputDialog("每周工作小时数："));
        salary = Double.parseDouble(JOptionPane.showInputDialog("每小时工资："));
        ntax = Double.parseDouble(JOptionPane.showInputDialog("国税率："));
        ltax = Double.parseDouble(JOptionPane.showInputDialog("地税率："));
        
        String result = "员工姓名：" + name +"\n\n"+
                        "每周工作小时数：" + hours + "\n" +
                        "每小时工资：" + salary + "\n" +
                        "每周工资总额：" + (salary * hours) +
                        "\t国税：" + (salary * hours * ntax) + "\n" +
                        "\t地税：" + (salary * hours * ltax) + "\n" +
                        "\t总税额：" + (salary * hours * (ntax + ltax)) + "\n" +
                        "实发工资额：" + (salary * hours * (1 - ntax - ltax));
        
        JOptionPane.showMessageDialog(null, result);
    }

}

