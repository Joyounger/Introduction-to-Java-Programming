
public class Exercise4_4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\t英里\t千米");
		for(int i = 1;i <= 10;i ++){
			System.out.println("\t" + i + "\t" + i*1.609);
		}
	}

}
