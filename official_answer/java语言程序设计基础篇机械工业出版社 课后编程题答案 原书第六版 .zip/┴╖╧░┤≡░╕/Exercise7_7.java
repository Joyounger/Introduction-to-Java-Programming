
public class Exercise7_7 {
	public static void main(String[] args) {
		Time time = new Time();
		System.out.println(time.toString());
		Time t = new Time(555550000);
		System.out.println(t.toString());
	}

}
class Time{
	private int hour;
	private int minute;
	private int second;
	private long totalMillis;
	public Time(){
		this(System.currentTimeMillis());
	}
	public Time(long millis){
		this.totalMillis = millis;
		second = (int)(totalMillis / 1000) % 60;
		minute = (int)(totalMillis / 60000) % 60;
		hour = (int)(totalMillis / 3600000) % 24;
	}
	/**
	 * @return the hour
	 */
	public int getHour() {
		return hour;
	}
	/**
	 * @return the minute
	 */
	public int getMinute() {
		return minute;
	}
	/**
	 * @return the second
	 */
	public int getSecond() {
		return second;
	}
	public String toString(){
		return hour + "hour " + minute + " minitue  " + second + " second ";
	}
}