import javax.swing.JOptionPane;


public class Exercise4_8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = Integer.parseInt(JOptionPane.showInputDialog("输入学生数量："));
		String name = "";
		double score = 0;
		String output = "最高分为：\n";
		for(int i = 0;i < num;i++){
			String oneName = JOptionPane.showInputDialog("输入姓名：");
			double scoreOfOne = Double.parseDouble(JOptionPane.showInputDialog("输入分数："));
			if(scoreOfOne > score){
				score = scoreOfOne;
				name = oneName;
			}else if(score == scoreOfOne){
				output += "姓名：" + oneName + " 分数: " + scoreOfOne + "\n";
			}		
		}
		output += "姓名：" + name + " 分数: " + score + "\n";
		JOptionPane.showMessageDialog(null, output);
	}

}
