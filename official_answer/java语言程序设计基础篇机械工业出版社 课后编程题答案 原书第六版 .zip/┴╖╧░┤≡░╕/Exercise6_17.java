
public class Exercise6_17 {
	public static void main(String[] args){
		int[] list = new int[100];
		for(int i = 0; i <list.length; i++)
			list[i] = (int)(Math.random()*300);
		selectionSort(list);
		for(int i = 0; i <list.length;i++)
			if((i+1)%10 == 0)
				System.out.println(list[i]);
			else
				System.out.print(list[i] + "  ");
	}

	private static void selectionSort(int[] list) {
		for(int i = list.length - 1; i >= 1 ;i--){
			int currentMax = list[0];
			int currentMinIndex = 0;
			for(int j = 1; j<= i; j++)
				if(currentMax < list[j]){
					currentMax = list[i];
					currentMinIndex = j;
				}
			if(currentMinIndex != i){
				list[currentMinIndex] = list[i];
				list[i] = currentMax;
			}		
		}
	}
}
