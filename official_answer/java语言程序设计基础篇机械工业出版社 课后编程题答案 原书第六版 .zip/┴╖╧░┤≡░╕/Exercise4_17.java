import javax.swing.JOptionPane;


public class Exercise4_17 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double sought = Double.parseDouble(JOptionPane.showInputDialog("输入提成："));
		double salesAmount = 0;
		for(double commission = -1;commission < sought; salesAmount += 0.01 ){
			if(salesAmount >= 10000.01)
				commission = 5000*0.08 + 5000*0.1 + (salesAmount - 10000)*0.12;
			else if(salesAmount >= 5000.01)
				commission = 5000*0.08 + (salesAmount - 5000)*0.1;
			else
				commission = salesAmount*0.08;
		}
		String output = "The sales amount $ " +(int)(salesAmount*100)/100.0 + 
			"\n is needed to make a commission of $ " + sought;
		JOptionPane.showMessageDialog(null,output);
	}

}
