import java.util.Calendar;
import java.util.GregorianCalendar;


public class Exercise9_2 {
	
	class Person{
		private String name;
		private String address;
		private String phone;
		private String email;
		
		public Person(String name){
			this.name = name;
		}
		public Person(){
			this("Smith");
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String toString(){
			
			return "class: Person\tname: " + name;
			
		}
		
	}
	
	class Student extends Person{
		private final int ONE = 1;
		private final int TWO = 2;
		private final int THREE = 3;
		private final int FOUR = 4;
		private int status;
		public Student(String name){
			super(name);
			status = ONE;
		}
		public int getStatus() {
			return status;
		}
		public void setStatus(int status) {
			this.status = status;
		}
		public String toString(){
			return "class: Student\tname: " + getName();
		}
	}
	
	class Employee extends Person{
		
		private String office;
		private double payment;
		private String date;
		
		public Employee(String name){
			super(name);
		}

		public String getOffice() {
			return office;
		}

		public void setOffice(String office) {
			this.office = office;
		}

		public double getPayment() {
			return payment;
		}

		public void setPayment(double payment) {
			this.payment = payment;
		}

		public String getDate() {
			return date;
		}

		public void setDate(MyDate date) {
			this.date = date.toString();
		}
		
		public String toString(){
			return "class: Employeetname: " + getName();
		}
		
	}
	
	class MyDate{
		
		private int year;
		private int month;
		private int day;
		
		public MyDate(int year,int month,int day){
			this.year = year;
			this.month = month;
			this.day = day;
		}
		public MyDate(){
			Calendar calendar = new GregorianCalendar();
			this.year = calendar.get(Calendar.YEAR);
			this.month = calendar.get(Calendar.MONTH);
			this.day = calendar.get(Calendar.DATE);
			
		}
		public int getYear() {
			return year;
		}
		public void setYear(int year) {
			this.year = year;
		}
		public int getMonth() {
			return month;
		}
		public void setMonth(int month) {
			this.month = month;
		}
		public int getDay() {
			return day;
		}
		public void setDay(int day) {
			this.day = day;
		}
		public String toString(){
			return year + " - " + month + " - " + day;
		}
	}
	
	class Faculty extends Employee{
		
		private int worktime;
		private String status;
		
		public Faculty(String name) {
			super(name);
		}

		public int getWorktime() {
			return worktime;
		}

		public void setWorktime(int worktime) {
			this.worktime = worktime;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}
		public String toString(){
			return "class: Faculty\tname: " +getName();
		}
	}
	public static void main(String[] args) {
		
	}

}
