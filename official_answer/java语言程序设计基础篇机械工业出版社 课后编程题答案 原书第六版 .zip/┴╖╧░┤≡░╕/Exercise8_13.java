public class Exercise8_13{
	public static void main(String[] args){
		if(args.length != 1 ){
			System.out.println("Usage: java Exercise8_13 string");
			System.exit(0);
			}
		System.out.println(args[0] + (isPalindrome(args[0])? "��" : "����") + "���Ĵ�");
		}
	public static boolean isPalindrome(String s){
		int low = 0;
		int high  = s.length() - 1;
		while(low < high){
			if(s.charAt(low) != s.charAt(high))
				return false;
			low ++;
			high --;
			}
		return true;
		}

	}