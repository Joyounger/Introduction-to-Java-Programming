import javax.swing.JOptionPane;


public class Exercise4_2 {
	public static void main(String[] args){
		int sum = 0,count1 = 0,count2 = 0,num;
		String output = "";
		while(true){
			num = Integer.parseInt(JOptionPane.showInputDialog("输入整数求平均数，以 0 为结束标志"));
			if(num == 0)
				break;
			sum += num;
			output += num + " , ";
			if(num > 0)
				count1 ++;
			else 
				count2 ++;
		}
		output += " 的平均数为：" + (double)sum/(count1 + count2) +
			"\n正数的个数为：" + count1 + 
			"\n负数的个数为：" + count2;
		JOptionPane.showMessageDialog(null,output);
	}
}
