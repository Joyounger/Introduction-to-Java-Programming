
public class Exercise4_19 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int NUM = 7;
		int row = NUM;
		int column = 0;
		int number = 0;
		String output = "";
		for(int i = 0;i <= row; i++){
			for(column = 1; column <= 7-i;column ++)
				System.out.print("     ");
			for(int j = 0;j<=i;j++){
				number = (int)Math.pow(2, j);
				if(number < 10)
					output = "    ";
				else if(number < 100)
					output = "   ";
				else 
					output = "  ";
				output += number;
				System.out.print(output);
			}
			for(int j = i-1; j >= 0;j--){
				number = (int)Math.pow(2, j);
				if(number < 10)
					output = "    ";
				else if(number < 100)
					output = "   ";
				else 
					output = "  ";
				output += number;
				System.out.print(output);
			}
			System.out.println();
		}
	}

}
