import javax.swing.JOptionPane;
public class Exercise2_13a{
    public static void main(String[] args){
        double balance = Double.parseDouble(JOptionPane.showInputDialog(null,"�������"));
        double annualInterestRate = Double.parseDouble(JOptionPane.showInputDialog(null,"����������"));
        double interest = balance*(annualInterestRate/1200);
        String output = "����Ϊ" + interest;
        JOptionPane.showMessageDialog(null,output);
        }
    }