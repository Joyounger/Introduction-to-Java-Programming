
public class Exercise4_20 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int MAX_NUMBER = 2000;
		final int MIN_NUMBER = 2;
		int count = 0;
		int number = MIN_NUMBER;
		System.out.println("输出2~2000的所有素数：");
		while(number < MAX_NUMBER){
			boolean isPrime = true;
			for(int divisor = 2; divisor <= number/2;divisor++){
				if(number%divisor == 0){
					isPrime = false;break;
				}
			}
			if(isPrime){
				count++;
				String output = "";

				if(count % 10 == 0)
					System.out.println(output );
				else
					System.out.print(output);
			}
			number ++;
		}
	}

}
