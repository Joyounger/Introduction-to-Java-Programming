
public class Exercise7_8 {

	public static void main(String[] args) {
		Course course = new Course("Data Structure");
		course.addStudent("xuande");
		course.addStudent("zitong");
		course.addStudent("xuanxiude");
		String[] student = course.getStudent();
		System.out.print("学生的数量为：" + course.getNumberOfSutdents()+ "\n姓名为：");
		for(int i = 0;i < course.getNumberOfSutdents();i++)
			System.out.print(student[i] + "  ");
	}

}
class Course{
	private String name;
	private String[] student = new String[2];
	private int numberOfSutdents;
	public Course(String name){
		this.name = name;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the student
	 */
	public String[] getStudent() {
		return student;
	}
	/**
	 * @param student the student to set
	 */
	public void setStudent(String[] student) {
		this.student = student;
	}
	/**
	 * @return the numberOfSutdents
	 */
	public int getNumberOfSutdents() {
		return numberOfSutdents;
	}
	public void addStudent(String student){
		if(numberOfSutdents >= this.student.length)
			this.student = addArrayLength(this.student);
		this.student[numberOfSutdents] = student;
		numberOfSutdents++;
	}
	private String[] addArrayLength(String[] array) {
		String[] newArray = new String[array.length + 5];
		System.arraycopy(array, 0, newArray, 0, array.length);
		return newArray;
	}


}
