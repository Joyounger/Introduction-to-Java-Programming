import javax.swing.JOptionPane;


public class Exercise4_9 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = Integer.parseInt(JOptionPane.showInputDialog("输入学生数量："));
		double scoreFirst = 0;
		double scoreSecond = 0;
		String nameFirst = "";
		String nameSecond = "";
		String output = "名次        姓名        分数\n";
		for(int i = 0;i < num;i++){
			String oneName = JOptionPane.showInputDialog("输入姓名：");
			double score = Double.parseDouble(JOptionPane.showInputDialog("输入分数："));
			if(score >= scoreFirst){
				nameFirst = oneName;
				scoreFirst = score;
			}else if(score > scoreSecond){
				nameSecond = oneName;
				scoreSecond = score;
			}
		}
		output += "   1          " + nameFirst + "            " + scoreFirst + "\n" + 
				  "   2          " + nameSecond + "            " + scoreSecond + "\n";
		JOptionPane.showMessageDialog(null, output);
	}

}
