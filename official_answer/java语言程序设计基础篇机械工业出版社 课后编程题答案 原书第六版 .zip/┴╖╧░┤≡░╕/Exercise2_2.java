import javax.swing.JOptionPane;

public class Exercise2_2 {

    public static void main(String[] args) {
        double radius, height;
        double area, volume;

        radius = Double.parseDouble(JOptionPane.showInputDialog("����뾶��"));
        height = Double.parseDouble(JOptionPane.showInputDialog("����߶ȣ�"));

        area = Math.PI * radius * radius;
        volume = area * height;

        volume = (int)(volume*100)/100.0;

        JOptionPane.showMessageDialog(null, "�뾶Ϊ��" + radius +
                                            ", �߶�Ϊ��" + height +
                                            "��Բ������ǣ�" + volume);
    }
}