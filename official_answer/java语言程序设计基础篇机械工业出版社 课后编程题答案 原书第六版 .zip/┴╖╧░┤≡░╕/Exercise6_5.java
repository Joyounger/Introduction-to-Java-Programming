import javax.swing.JOptionPane;
public class Exercise6_5{
	public static void main(String[] args){
		int[] num = new int[10];
		boolean zero = false;
		int j = 0;
		for(int i = 0;i < 10 ;i++){
			int number = Integer.parseInt(JOptionPane.showInputDialog("Enter a number:"));
			if(number == 0)
				zero = true;
			if(number != 0)
				for(j = 0;j <= i; j++)
					if(num[j] == number)
						break;
			if(j >= i)
				num[i] = number;

			}
		if(zero)
			System.out.println(0);
		for(int i = 0;i < num.length;i++)
			if(num[i] != 0)
				System.out.println(num[i]);
		}
	}