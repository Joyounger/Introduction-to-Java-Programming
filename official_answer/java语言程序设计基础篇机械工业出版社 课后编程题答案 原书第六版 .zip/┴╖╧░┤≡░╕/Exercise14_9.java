import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise14_9 extends JFrame {

	/**
	 * @param args
	 */
	public Exercise14_9(){
		JPanel jp = new DrawLineWhenKeyPressed();
		add(jp);
		jp.setFocusable(true);
	}
	public static void main(String[] args) {
		Exercise14_9 frame = new Exercise14_9();
		frame.setTitle("Exercise14_9");
		frame.setSize(200,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	static class DrawLineWhenKeyPressed extends JPanel{
		private int[] xPoints = new int[100];
		private int[] yPoints = new int[100];
		private int x = 0;
		private int y = 0;
		private int interval = 1;
		private int i = 0;
		public DrawLineWhenKeyPressed(){
			addKeyListener(new KeyAdapter(){
				public void keyPressed(KeyEvent e){
					switch(e.getKeyCode()){
					case KeyEvent.VK_UP: y -= interval;break;
					case KeyEvent.VK_DOWN: y += interval;break;
					case KeyEvent.VK_LEFT: x -= interval;break;
					case KeyEvent.VK_RIGHT: x += interval;break;	
					}
					repaint();
				}
				public void keyReleased(KeyEvent e){
					xPoints[i] = x;
					yPoints[i] = y;
					i++;
					repaint();
				}
			});
		}
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			g.setColor(Color.red);
			g.drawPolyline(xPoints, yPoints, i+1);
			g.setColor(getBackground());
			g.drawLine(0,0,xPoints[i], yPoints[i]);
		}
	}
}
