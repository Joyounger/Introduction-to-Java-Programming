import javax.swing.JOptionPane;


public class Exercise3_5 {

	public static void main(String[] args) {
		int num1 = (int)(System.currentTimeMillis()%10);
		int num2 = (int)(System.currentTimeMillis()*7%10);
		int num3 = (int)(System.currentTimeMillis()*13%10);
		String answerString = JOptionPane.showInputDialog("What is " + num1 + 
				" + " + num2 + " + " + num3 + " = ?");
		int answer = Integer.parseInt(answerString);
		JOptionPane.showMessageDialog(null, num1 + " + " + num2 + " + " + num3 + " = " + answer + 
				" is " + (num1+num2+num3==answer));
	}

}
