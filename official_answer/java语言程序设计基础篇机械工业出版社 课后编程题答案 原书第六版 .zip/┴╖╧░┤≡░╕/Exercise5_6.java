import javax.swing.JOptionPane;
public class Exercise5_6{
	public static void main(String[] args){
		int num = Integer.parseInt(JOptionPane.showInputDialog(null,"�������������������"));
		displayPattern(num);
		}
	public static void displayPattern(int n){
		for(int i = 1;i<=n;i++){
			for(int k=n-i;k>0;k--)
				System.out.print("    ");
			for(int k=i;k>0;k--){
				if(k<10)
					System.out.print("   "+k);
				else if(k<100)
						System.out.print("  "+k);
					 else
					 	System.out.print(" "+k);
				}
		System.out.println("\n");
			}
		}
	}