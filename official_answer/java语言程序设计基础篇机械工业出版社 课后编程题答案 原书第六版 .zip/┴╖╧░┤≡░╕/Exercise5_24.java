import javax.swing.JOptionPane;
public class Exercise5_24 {
	public static void main(String[] args){
		JOptionPane.showMessageDialog(null,"��ǰ��ϵͳʱ��Ϊ��" + displayCurrentDateTime());
	}

	private static String displayCurrentDateTime() {
		// TODO Auto-generated method stub
		long totalMillisSeconds = System.currentTimeMillis();
		long totalSeconds = totalMillisSeconds/1000;
		int currentSecond = (int)(totalSeconds%60);
		long totalMinutes = totalSeconds / 60;
		int currentMinute = (int)(totalMinutes % 60);
		long totalHours = totalMinutes / 60;
		int currentHour = (int)(totalHours % 60);
		int totalDays = (int)(totalHours / 24);
		int year = 1970;
		int days = 0;
		for(days = 0;days < totalDays;year++){
			days += isLeapYear(year - 1)? 366 : 365;
		}
		year--;
		days -= isLeapYear(year - 1)? 366 : 365;
		days = totalDays - days;
		int month = 0;
		int dayOfYear = 0;
		for(dayOfYear = 0;dayOfYear < days; month++){
			dayOfYear += getDaysOfMonth(year,month);
		}
		int date = dayOfYear - days;
		int dayOfMonth = getDaysOfMonth(year,month);
		date = dayOfMonth - date;
		String currentDateTime = year + " ��   " + month + " �� " + date + " �� " +
			currentHour + " : " + currentMinute + " : " + currentSecond ;
		return currentDateTime;
	}

	private static int getDaysOfMonth(int year, int month) {
		int days;
		if(isLeapYear(year)&&month == 2)
			days = 29;
		else if(month == 2)
			days = 30;
		else if(month == 4||month == 6||month == 9||month == 11)
			days = 30;
		else if(month == 2)
			days = 0;
		else days = 31;
		return days;
	}

	private static boolean isLeapYear(int year) {
		// TODO Auto-generated method stub
		return ((year % 4 == 0 && year % 100 != 0)||(year % 400 == 0));
	}
}
