
public class Exercise4_25 {

	public static void main(String[] args) {
		//注意变量count和pi的作用域。如果设成全局变量，就会出现问题。
		for(int i = 10000; i <= 100000; i += 10000){
			int count = 0;
			double pi = 0;
			for(int j = 1; j <= (2*i + 1);j += 2){
				count++;
				if(count % 2 == 0)
					pi -= 1.0/j;
				else 
					pi += 1.0/j;
			}
			System.out.println("当 i = " + i + " 时π的值为：" + pi*4);
		}
		
	}

}
