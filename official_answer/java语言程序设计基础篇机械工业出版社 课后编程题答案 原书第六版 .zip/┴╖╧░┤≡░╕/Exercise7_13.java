
public class Exercise7_13 {

	public static void main(String[] args) {
		StackOfIntegers stack = new StackOfIntegers();
		int j;
		for(int i = 2;i < 120;i++){
			for(j = 2;j<=i/2;j++)
				if(i%j ==0)
					break;
			if(j > i/2)
				stack.push(i);
		}
		System.out.println("��ʾС��120��������");
		int count = 0;
		while(!stack.empty()){
			count++;
			if(count % 10 == 0)
				System.out.println(stack.pop());
			else
				System.out.print(stack.pop() + "  ");
		}
	}

}