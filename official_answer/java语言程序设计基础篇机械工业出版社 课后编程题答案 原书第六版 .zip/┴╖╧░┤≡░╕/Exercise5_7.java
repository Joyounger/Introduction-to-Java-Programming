import java.util.Scanner;
public class Exercise5_7{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("����Ͷ�ʶ");
		double inverestmentAmount = input.nextDouble();
		System.out.print("���������ʣ�");
		double yearlyInterestRate = input.nextDouble();
		System.out.println("\nͶ�ʶ" + inverestmentAmount);
		System.out.println("�����ʣ�" + yearlyInterestRate);
		System.out.println("����\t��ֵ");
		for(int year = 1;year<=30;year++){
			System.out.println(year +"\t" + futureInvestmentValue(inverestmentAmount,yearlyInterestRate/12.0,year));
			}
		}
	public static double futureInvestmentValue(double investmentAmount,double monthlyInterestRate,int year){
		double futureInvestmentValue =
			Math.pow((1+monthlyInterestRate),year*12)*investmentAmount;
		futureInvestmentValue = Math.round(futureInvestmentValue*100)/100.0;
		return futureInvestmentValue;
		}
	}