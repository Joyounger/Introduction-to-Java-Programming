import javax.swing.JOptionPane;
public class Exercise3_12{
	public static void main(String[] args){
		int num = Integer.parseInt(JOptionPane.showInputDialog("����һ��������"));
		String output = "";
		if(num % 5 == 0 && num % 6 == 0)
			output = num + " is divisible by 5 and 6 .";
		else if(num % 5 == 0 ^ num % 6 == 0)
			output = num + " is divisible by 5 or 6 ,but not both";
		else
			output = num + " is not divisible by either 5 or 6 .";
		JOptionPane.showMessageDialog(null,output);
		}
	}