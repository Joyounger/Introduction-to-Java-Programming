import javax.swing.JOptionPane;
public class Exercise3_4{
    public static void main(String[] args){
           int num1 = (int)(Math.random()*100);
           int num2 = (int)(Math.random()*100);
           String output = num1 + " + " + num2 + " = ";
           int sum = Integer.parseInt(JOptionPane.showInputDialog(null,output));
           if(sum == num1+num2)
                output += sum +" ? " +"true";
           else
                output += sum +" ? " +"false";

           JOptionPane.showMessageDialog(null,output);

        }
    }