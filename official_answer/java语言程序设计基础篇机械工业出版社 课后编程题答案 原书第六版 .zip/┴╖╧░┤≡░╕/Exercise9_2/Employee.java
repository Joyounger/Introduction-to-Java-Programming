public class Employee extends Person{

		private String office;
		private double payment;
		private String date;

		public Employee(String name){
			super(name);
		}

		public String getOffice() {
			return office;
		}

		public void setOffice(String office) {
			this.office = office;
		}

		public double getPayment() {
			return payment;
		}

		public void setPayment(double payment) {
			this.payment = payment;
		}

		public String getDate() {
			return date;
		}

		public void setDate(MyDate date) {
			this.date = date.toString();
		}

		public String toString(){
			return "class: Employee\tname: " + getName();
		}

	}