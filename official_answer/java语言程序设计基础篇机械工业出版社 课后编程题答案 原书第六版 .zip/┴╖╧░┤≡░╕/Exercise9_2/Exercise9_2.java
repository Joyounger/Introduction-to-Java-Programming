public class Exercise9_2{
	public static void main(String[] args){
		Person person = new Person();
		Student student = new Student("xuande");
		Employee employee = new Employee("zitong");
		Faculty faculty = new Faculty("xuanxiude");
		Staff staff = new Staff("zitong00");
		System.out.println(person.toString() + "\n" +
			student.toString() + "\n" +
			employee.toString() + "\n" +
			faculty.toString() + "\n" +
			staff.toString());
	}
}