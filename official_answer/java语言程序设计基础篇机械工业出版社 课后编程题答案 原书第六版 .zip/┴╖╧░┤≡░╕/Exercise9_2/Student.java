public class Student extends Person{
		private final int ONE = 1;
		private final int TWO = 2;
		private final int THREE = 3;
		private final int FOUR = 4;
		private int status;
		public Student(String name){
			super(name);
			status = ONE;
		}
		public int getStatus() {
			return status;
		}
		public void setStatus(int status) {
			this.status = status;
		}
		public String toString(){
			return "class: Student\tname: " + getName();
		}
	}