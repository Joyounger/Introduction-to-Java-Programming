public class Staff extends Employee{
	private String mingcheng;
	public Staff(String name){
		super(name);
	}
	public String getMingcheng(){
		return mingcheng;
	}
	public void setMingcheng(String mingcheng){
		this.mingcheng = mingcheng;
	}
	public String toString(){
		return "class: Staff\tname: " + getName();
	}
}