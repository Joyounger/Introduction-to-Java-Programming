public class Faculty extends Employee{
		
		private int worktime;
		private String status;
		
		public Faculty(String name) {
			super(name);
		}

		public int getWorktime() {
			return worktime;
		}

		public void setWorktime(int worktime) {
			this.worktime = worktime;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}
		public String toString(){
			return "class: Faculty\tname: " +getName();
		}
	}