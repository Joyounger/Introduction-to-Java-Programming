import javax.swing.JOptionPane;
public class Exercise5_22{
	public static void main(String[] args){
		double num = Double.parseDouble(JOptionPane.showInputDialog("����һ������ƽ����:"));
		double i = Double.parseDouble(JOptionPane.showInputDialog("����Ҫ�󾫶�(���磺0.0001):"));
		double sqrt = sqrt(num,i);
		JOptionPane.showMessageDialog(null,num + "��ƽ����Ϊ��" + sqrt);
		}
	public static double sqrt(double num, double i){
		double nextGuess = 0,lastGuess = num;int count =0;
		while(Math.abs(nextGuess - lastGuess)>i){
			nextGuess = (lastGuess + (num/lastGuess))/2;
			lastGuess = (lastGuess + nextGuess)/2;
			count ++;
			}
		System.out.println(count);
		return lastGuess;
		}
	}