import javax.swing.JOptionPane;


public class Exercise8_1 {

	public static void main(String[] args) {
		String s= JOptionPane.showInputDialog("����һ���ַ���");
		String output = "";
		if(isPalindrome(s))
			output = s + " �ǻ��Ĵ�";
		else 
			output = s + " ���ǻ��Ĵ�";
		JOptionPane.showMessageDialog(null,output);
	}

	private static boolean isPalindrome(String s) {
		return reverse(s).equals(s);
	}

	private static String reverse(String s) {
		char ch[] = new char[s.length()];
		for(int i = 1; i <= s.length();i++)
			ch[i - 1] = s.charAt(s.length() - i);
		return String.valueOf(ch);
	}

}
