import javax.swing.JOptionPane;


public class Exercise4_16 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = Integer.parseInt(JOptionPane.showInputDialog("输入一个整数："));
		String output = num + " 的所有素数因子: ";
		int i = 2;
		while(i < num){
			if(num % i == 0){
				output += i + " , ";
				num /= i;
			}else i++;
		}
		output += i;//目的是为了去掉输出中最后的逗号。如果循环条件是（i<=num）则输出结果多一个逗号。
		JOptionPane.showMessageDialog(null, output);
	}

}
