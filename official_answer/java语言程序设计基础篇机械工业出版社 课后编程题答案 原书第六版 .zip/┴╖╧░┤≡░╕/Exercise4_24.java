public class Exercise4_24{
	public static void main(String[] args){
		double sum = 0;
		for(int i = 1;i <= 97;i++)
		sum +=(double)i / (i + 2);
		System.out.println("1/3 + 3/5 + ... +97/99 = " + sum);
		}
	}