
public class Exercise4_27 {

	public static void main(String[] args) {
		boolean isLeapYear = false;
		int count = 0;
		System.out.println("21世纪所有的闰年是:");
		for(int year = 2001;year <= 2100;year++){
			isLeapYear = ((year % 4 ==0&& year % 100 != 0)||(year % 400 == 0));
			if(isLeapYear){
				count++;
				if(count % 10 == 0)
					System.out.println(year);
				else
					System.out.print(year + " ");
			}
		}
	}

}
