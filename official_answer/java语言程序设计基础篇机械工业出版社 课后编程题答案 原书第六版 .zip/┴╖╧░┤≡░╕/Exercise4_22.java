import javax.swing.JOptionPane;
public class Exercise4_22{
	public static void main(String[] args){
		double interest = 0;
		double principal = 0;
		double balance = Double.parseDouble(JOptionPane.showInputDialog(null,"�����"));
		double numberOfYear = Double.parseDouble(JOptionPane.showInputDialog(null,"����������"));
		double yearlyInterestRate = Double.parseDouble(JOptionPane.showInputDialog(null,"�����ʣ�"));
		double monthlyInterestRate = yearlyInterestRate/12.0;
		double payment = Math.pow((1 + monthlyInterestRate),(numberOfYear*12))*balance;
		double monthlyPayment = (int)(payment/(numberOfYear*12)*100)/100.0;
		System.out.println("�����ܶ" + balance +
			"\n������" + numberOfYear + "\n��֧���" +
			monthlyPayment + "\n�ܳ����" + payment +"\n");
		System.out.println("\t�·�\t��Ϣ\t����\t���");
		for(int i = 1; i<= numberOfYear*12;i++){
			interest = monthlyInterestRate * balance;
			principal = monthlyPayment - interest;
			balance -= principal;
			System.out.println(" " + i + "\t" + interest + "\t" +
				principal + "\t" +balance);
			}
	}
}