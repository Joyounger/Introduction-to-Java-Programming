import javax.swing.JOptionPane;


public class Exercise4_15 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1 = Integer.parseInt(JOptionPane.showInputDialog("求最大公约数,输入第一个数："));
		int num2 = Integer.parseInt(JOptionPane.showInputDialog("求最大公约数，输入第二个数："));
		int d = num1 > num2 ? num1 : num2;
		while(d > 0){
			if(num1 % d == 0 && num2 % d == 0)
				break;
			d--;
		}
		JOptionPane.showMessageDialog(null,num1 + " , " + num2 +" 最大公约数为：" + d);
	}

}
