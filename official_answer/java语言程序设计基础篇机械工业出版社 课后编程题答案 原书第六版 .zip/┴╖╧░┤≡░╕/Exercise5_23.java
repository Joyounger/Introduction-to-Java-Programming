
public class Exercise5_23 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i =0;i<100;i++){
			char ch = RandomCharacter.getRandomUpperCaseLetter();
			if((i + 1)%10 == 0)
				System.out.println(ch);
			else System.out.print(ch + " ");
		}
		System.out.println();
		for(int i =0;i<100;i++){
			char ch = RandomCharacter.getRandomDigitCharacter();
			if((i + 1)%10 == 0)
				System.out.println(ch);
			else System.out.print(ch + " ");
		}
	}

}
class RandomCharacter{

	public static char getRandomUpperCaseLetter() {
		// TODO Auto-generated method stub
		return getRandomCharacter('A','Z');
	}

	private static char getRandomCharacter(char c, char d) {
		// TODO Auto-generated method stub
		return (char)(c + Math.random()*(d-c+1));
	}

	public static char getRandomDigitCharacter() {
		// TODO Auto-generated method stub
		return getRandomCharacter('0','9');
	}
	
}