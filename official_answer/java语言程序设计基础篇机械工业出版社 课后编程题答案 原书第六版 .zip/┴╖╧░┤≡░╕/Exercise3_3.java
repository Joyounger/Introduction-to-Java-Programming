import javax.swing.JOptionPane;
public class Exercise3_3{
    public static void main(String[] args){
        int num = Integer.parseInt(JOptionPane.showInputDialog(null,"����һ������"));
        String output = "Is " + num + " divisible by 5 and 6 ? "+ isDivisibleBoth(num) +
            "\nIs " + num + " divisible by 5 or 6 ? "+ isDivisibleOr(num) +
            "\nIs " + num + " divisible by 5 or 6 , but not both ? "+ isDivisible(num);
        JOptionPane.showMessageDialog(null,output);
        }
    private static boolean isDivisible(int num){
        if(num%5==0 ^ num%6==0)
            return true;
        else
            return false;
        }
    private static boolean isDivisibleBoth(int num){
            if(num%5==0 && num%6==0)
                return true;
            else
                return false;
        }
    private static boolean isDivisibleOr(int num){
            if(num%5==0 || num%6==0)
                return true;
            else
                return false;
        }
    }