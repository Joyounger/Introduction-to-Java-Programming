import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise14_7 extends JFrame {
	public Exercise14_7(){
		ShowMessage showMessage = new ShowMessage();
		add(showMessage);
		showMessage.setFocusable(true);
	}
	public static void main(String[] args) {
		Exercise14_7 frame = new Exercise14_7();
		frame.setTitle("Exercise14_7");
		frame.setSize(200,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

	}
	static class ShowMessage extends JPanel{
		private StringBuilder str = new StringBuilder();
		private int x = 20;
		private int y = 20;
		private int end = 0;
		public ShowMessage(){
			this.addKeyListener(new KeyAdapter(){
				public void keyPressed(KeyEvent e){
					if(e.getKeyCode() != KeyEvent.VK_ENTER)
						str.append(e.getKeyChar());
					else{
						repaint();
					}
						
				}
			});
		}
		protected void paintComponent(Graphics g){
			super.paintComponent(g);
			g.setFont(new Font("TimesRoman",Font.BOLD,24));
			g.drawString(str.toString(), x , y);
			end = str.length();
			str.delete(0, end);
		}
	}
}
