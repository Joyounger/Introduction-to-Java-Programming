import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Exercise13_10 extends JFrame{

	public Exercise13_10(){
		add(new DrawPanel());
	}
	public static void main(String[] args) {
		Exercise13_10 frame = new Exercise13_10();
		frame.setTitle("Exercise13_10");
		frame.setSize(400,400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
	}
	static class DrawPanel extends JPanel{

		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.drawOval(40, 30, (int) (getWidth()*0.8), 50);
			g.drawLine(40, 55, 40, 325);
			g.drawLine(40+(int) (getWidth()*0.8), 55, 40+(int) (getWidth()*0.8), 325);
			g.drawOval(40, 300, (int) (getWidth()*0.8), 50);
		}

	}
}
