import javax.swing.JOptionPane;
public class Exercise8_16{
	public static void main(String[] args){
		String money = JOptionPane.showInputDialog("����Ǯ����$");
		String[] str = money.split("\\.");
		int dollar = Integer.parseInt(str[0]);
		int cent = Integer.parseInt(str[1]);
		JOptionPane.showMessageDialog(null,money + " is " + dollar + "dollars and " + cent +" cents");
		}
	}