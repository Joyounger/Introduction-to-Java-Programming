import javax.swing.JOptionPane;
public class Exercise4_1 {
	public static void main(String[] args){
		int correctCount = 0;
		int count = 0;
		long startTime = System.currentTimeMillis();
		String output = "";
		while(count < 10 ){
			int num1 = (int)(Math.random()*15)+1;
			int num2 = (int)(Math.random()*15)+1;
			String answerString = JOptionPane.showInputDialog("what is " + 
						num1 + " + " + num2 + " ?");
			int answer = Integer.parseInt(answerString);
			String replyString = "";
			if(num1 + num2 == answer){
				replyString = "You are correct!";
				correctCount ++;		
			}else
				replyString = "you are wrong\n" + num1 + " + " + num2 +
					" shoule be " + (num1 + num2);
			JOptionPane.showMessageDialog(null,replyString);
			count ++;
			output += "\n" + num1 + " + " +num2 + " = " + answerString + 
				((num1 + num2 == answer)? " correct" : " wrong");
		}
		long endTime = System.currentTimeMillis();
		long testTime = endTime - startTime;
		JOptionPane.showMessageDialog(null, "Correct count is " + correctCount +
				"\n" + testTime/1000 + " seconds\n" + output);
	}
}
