public class Exercise1_8 {
  public static void main(String[] args) {
  	// Display area
    System.out.println(5.5 * 5.5 * 3.14159);

    // Display perimeter
    System.out.println(2 * 5.5 * 3.14159);
  }
}