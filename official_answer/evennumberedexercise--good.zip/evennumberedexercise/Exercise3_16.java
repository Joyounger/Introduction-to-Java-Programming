public class Exercise3_16 {
  public static void main(String[] args) {
    System.out.println((char)('A' + Math.random() * 27));
  }
}
