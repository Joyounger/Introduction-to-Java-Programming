
public class SimpleEventDemo {


  public static void main(String[] args) {
    
    
    int i = Integer.MAX_VALUE + 1;
    System.out.println(i);
    
    System.out.println(Double.MIN_VALUE / 10.0);
    System.out.println(Double.MAX_VALUE * 10.0);
  }
}
